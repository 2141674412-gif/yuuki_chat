"""
yuuki_chat - 结城希亚 QQ Bot 插件
NoneBot2 插件，基于 Ollama 本地 AI 的聊天机器人

模块结构：
  config.py   - 配置常量、人设管理
  utils.py    - 工具函数（字体、绘图、封面下载）
  chat.py     - AI 聊天处理器
  commands.py - 基础命令（签到、抽签、翻译等）
  maimai.py   - 舞萌DX查询（B50/B40/单曲）
"""

from .chat import chat
from .commands import *
from .maimai import mai_cmd

__all__ = ["chat", "mai_cmd"]
