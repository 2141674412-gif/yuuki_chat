# 标准库
import ast
import base64
import hashlib
import hmac
import json
import logging
import operator
import os
import random
import re
import secrets
import subprocess
import sys
import time
import zipfile
import shutil
from collections import Counter
from datetime import datetime, timedelta

# 第三方库
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import httpx
from nonebot import on_command, get_driver, logger
from nonebot.adapters.onebot.v11 import Bot, GroupMessageEvent, MessageEvent, MessageSegment
from nonebot.exception import FinishedException

# ---- 全局 HTTP 客户端（连接池复用） ----
from .utils import get_shared_http_client as _get_http_client

# 安全日志：脱敏敏感信息
class _SafeFormatter(logging.Formatter):
    """日志格式化器，自动脱敏敏感词"""
    _SENSITIVE_KEYS = ["token", "password", "密码", "friend_code", "好友码"]
    def format(self, record):
        msg = super().format(record)
        for key in self._SENSITIVE_KEYS:
            # 脱敏 key=value 或 key: value 模式
            msg = re.sub(
                rf'({key})["\s:=]+(["\']?)([^\s"\'\]}}]+)(["\']?)',
                rf'\1=\2***\4',
                msg,
                flags=re.IGNORECASE
            )
        return msg

# 设置日志脱敏
for _handler in logging.root.handlers:
    try:
        if hasattr(_handler, 'formatter') and _handler.formatter and hasattr(_handler.formatter, 'format_string'):
            _handler.setFormatter(_SafeFormatter(_handler.formatter.format_string))
    except Exception:
        pass

# 从子模块导入配置和聊天处理
from .config import load_persona, save_persona, PERSONA_FILE
from .chat import chat_history

# ========== 路径常量 ==========

_DATA_DIR = os.path.join(os.getcwd(), "yuuki_data")
os.makedirs(_DATA_DIR, exist_ok=True)
CHECKIN_FILE = os.path.join(_DATA_DIR, "checkin_records.json")
REMINDERS_FILE = os.path.join(_DATA_DIR, "reminders.json")

# ========== superusers ==========

superusers = []
try:
    from nonebot import get_driver
    driver = get_driver()
    _su = driver.config.dict().get("superusers", [])
    if _su:
        superusers = [str(s) for s in _su]
except Exception as e:
    logger.warning(f"[superusers加载失败] {e}")

# 兜底：直接读环境变量
if not superusers:
    raw = os.getenv("superusers", "")
    if raw:
        raw = raw.strip()
        if raw.startswith("[") or raw.startswith("("):
            try:
                superusers = ast.literal_eval(raw)
            except (ValueError, SyntaxError):
                try:
                    superusers = json.loads(raw)
                except Exception:
                    pass
        else:
            superusers = [s.strip().strip("'\"") for s in raw.split(",") if s.strip()]
        superusers = [str(s) for s in superusers]

logger.info(f"[启动] superusers={superusers}")

# ========== 频率限制（防刷屏） ==========

_rate_limit = {}  # {user_id: last_cmd_time}
_RATE_COOLDOWN = 3  # 每个用户3秒内只能触发一次非AI命令

def _check_rate_limit(user_id: str) -> bool:
    """检查频率限制，返回 True 表示放行"""
    now = time.time()
    # 清理超过1小时的过期条目，防止内存泄漏
    if len(_rate_limit) > 1000:
        expired = [k for k, v in _rate_limit.items() if now - v > 3600]
        for k in expired:
            del _rate_limit[k]
    last = _rate_limit.get(user_id, 0)
    if now - last < _RATE_COOLDOWN:
        return False
    _rate_limit[user_id] = now
    return True

# ========== 签到记录 & 提醒存储 ==========

checkin_records = {}
reminders = {}

# -- 积分数据 --

POINTS_FILE = os.path.join(_DATA_DIR, "user_points.json")
user_points = {}

# -- 个人黑名单 --

BLACKLIST_FILE = os.path.join(_DATA_DIR, "user_blacklist.json")
user_blacklist = set()

def _load_blacklist() -> None:
    global user_blacklist
    if os.path.exists(BLACKLIST_FILE):
        try:
            with open(BLACKLIST_FILE, "r", encoding="utf-8") as f:
                user_blacklist = set(json.load(f))
        except (json.JSONDecodeError, OSError):
            user_blacklist = set()

def _save_blacklist() -> None:
    with open(BLACKLIST_FILE, "w", encoding="utf-8") as f:
        json.dump(sorted(user_blacklist), f, ensure_ascii=False, indent=2)

def _load_points() -> None:
    global user_points
    user_points = _load_json(POINTS_FILE)

def _save_points() -> None:
    _save_json(POINTS_FILE, user_points)

# ========== 持久化函数 ==========


def _load_json(filepath: str) -> dict:
    """从 JSON 文件加载数据，文件不存在或损坏时返回空字典。"""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def _save_json(filepath: str, data: dict) -> None:
    """将数据保存到 JSON 文件。"""
    try:
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError as e:
        logger.error(f"[commands] 保存文件失败 {filepath}: {e}")


def _load_checkin_records() -> None:
    global checkin_records
    checkin_records = _load_json(CHECKIN_FILE)


def _save_checkin_records() -> None:
    _save_json(CHECKIN_FILE, checkin_records)


def _load_reminders() -> None:
    global reminders
    raw = _load_json(REMINDERS_FILE)
    for user_id, items in raw.items():
        for r in items:
            for key in ("time", "created"):
                if key in r and isinstance(r[key], str):
                    try:
                        r[key] = datetime.fromisoformat(r[key])
                    except (ValueError, TypeError):
                        pass
    reminders = raw


def _save_reminders() -> None:
    serializable = {}
    for user_id, items in reminders.items():
        serializable[user_id] = []
        for r in items:
            entry = dict(r)
            for key in ("time", "created"):
                if key in entry and isinstance(entry[key], datetime):
                    entry[key] = entry[key].isoformat()
            serializable[user_id].append(entry)
    _save_json(REMINDERS_FILE, serializable)


_load_checkin_records()
_load_reminders()
_load_points()
_load_blacklist()

# ========== 数据迁移（旧路径 → 新路径） ==========

def _migrate_data():
    """启动时检查旧路径的数据文件，迁移到新路径（yuuki_data/）"""
    _plugin_dir = os.path.dirname(os.path.abspath(__file__))
    # 旧路径搜索顺序
    _old_dirs = [
        os.path.join(_plugin_dir, "data"),  # 插件目录下的 data（上一版）
        _plugin_dir,  # 插件根目录（旧版）
        os.path.join(os.path.dirname(_plugin_dir), "yuuki_data"),  # 上级的 yuuki_data（更早版本）
    ]
    _data_files = [
        "checkin_records.json", "reminders.json", "user_points.json",
        "allowed_groups.json", "user_blacklist.json", "persona.txt",
        "maimai_binds.json",
    ]
    for filename in _data_files:
        new_path = os.path.join(_DATA_DIR, filename)
        if os.path.exists(new_path):
            continue
        for old_dir in _old_dirs:
            old_path = os.path.join(old_dir, filename)
            if os.path.exists(old_path) and old_path != new_path:
                try:
                    shutil.copy2(old_path, new_path)
                    logger.info(f"[迁移] {filename}: {old_path} -> {new_path}")
                    break
                except Exception as e:
                    logger.error(f"[迁移] {filename} 失败: {e}")

_migrate_data()

# ========== 辅助函数 ==========


def check_superuser(user_id: str) -> bool:
    """检查用户是否为超级用户。"""
    return str(user_id) in superusers


# ========== 命令注册器 ==========


def _register(name, handler, aliases=None, priority=5, admin_only=False):
    """注册命令，可选别名、优先级和管理员限制。返回 matcher 对象。"""
    cmd = on_command(name, priority=priority)
    # 安全检查函数（主命令和别名共用）
    async def _safe_handler(event: MessageEvent):
        # 群白名单检查（默认不允许任何群，必须手动添加）
        from .config import ALLOWED_GROUPS
        if not ALLOWED_GROUPS:
            gid = getattr(event, 'group_id', None)
            if gid:
                return  # 没有配置白名单，所有群都不可用
        else:
            gid = getattr(event, 'group_id', None)
            if gid and gid not in ALLOWED_GROUPS:
                return  # 不在白名单群里，静默忽略
        if admin_only and not check_superuser(str(event.user_id)):
            await cmd.finish("...你不是管理员。")
            return
        # 黑名单检查（管理员不受限）
        if not check_superuser(str(event.user_id)) and str(event.user_id) in user_blacklist:
            return  # 黑名单用户，静默忽略
        # 频率限制（管理员不受限）
        if not admin_only and not _check_rate_limit(str(event.user_id)):
            return  # 冷却中，静默忽略
        await handler(event)

    if aliases:
        for a in aliases:
            cmd2 = on_command(a, priority=priority)
            @cmd2.handle()
            async def _alias_h(event: MessageEvent):
                await _safe_handler(event)
    @cmd.handle()
    async def _h(event: MessageEvent):
        await _safe_handler(event)
    return cmd


# ========== 安全计算器 ==========

_SAFE_OPERATORS = {
    ast.Add: operator.add, ast.Sub: operator.sub,
    ast.Mult: operator.mul, ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod,
    ast.Pow: operator.pow, ast.USub: operator.neg, ast.UAdd: operator.pos,
}


def _safe_eval_node(node: ast.AST) -> float:
    """递归求值 AST 节点，仅允许数字常量和白名单运算符。"""
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return float(node.value)
    if isinstance(node, ast.BinOp):
        op_type = type(node.op)
        if op_type not in _SAFE_OPERATORS:
            raise ValueError(f"不允许的运算符: {op_type.__name__}")
        left = _safe_eval_node(node.left)
        right = _safe_eval_node(node.right)
        if op_type in (ast.Div, ast.FloorDiv, ast.Mod) and right == 0:
            raise ZeroDivisionError("除数不能为零")
        if op_type is ast.Pow and abs(right) > 100:
            raise ValueError("幂运算指数过大")
        return _SAFE_OPERATORS[op_type](left, right)
    if isinstance(node, ast.UnaryOp):
        op_type = type(node.op)
        if op_type not in _SAFE_OPERATORS:
            raise ValueError(f"不允许的一元运算符: {op_type.__name__}")
        return _SAFE_OPERATORS[op_type](_safe_eval_node(node.operand))
    raise ValueError("不支持的表达式")


def safe_eval(expr: str) -> float:
    """安全地计算数学表达式，仅支持基本算术运算。"""
    tree = ast.parse(expr, mode="eval")
    return _safe_eval_node(tree.body)


# ========== 简单命令 ==========

# -- 帮助 --

async def _cmd_help(event: MessageEvent):
    content = str(event.message).strip()
    for prefix in ["帮助", "help"]:
        if content.lower().startswith(prefix):
            content = content[len(prefix):].strip()
            break

    page = 1
    if content in ("2", "二", "舞萌", "工具"):
        page = 2
    elif content in ("3", "三", "管理"):
        page = 3
    elif content in ("4", "四", "保险箱"):
        page = 4

    pages = {
        1: """【命令列表 1/4 — 基础命令】

日常
  /签到 — 每日签到（+积分）
  /积分 — 查看积分
  /排行 — 积分排行榜
  /抽签 /运势 /成语 /笑话 /谜语 /戳我

工具
  /天气 城市 — 查询天气
  /词云 — 聊天词频统计
  /计算器 /翻译 /汇率 /搜索 /提醒

AI对话
  @我 或提到希亚 — AI对话

→ /帮助 2 查看舞萌DX & 工具详情
→ /帮助 3 查看管理命令
→ /帮助 4 查看保险箱用法""",
        2: """【命令列表 2/4 — 舞萌DX & 工具】

舞萌DX
/mai b50 [用户名] — 查B50成绩
/mai b40 [用户名] — 查B40成绩
/mai 歌曲 歌名 — 查单曲信息
/牌子 — 查版本牌子进度
/绑定 — 查看绑定（私聊）
/绑定 好友码 — 绑好友码（私聊）
/绑定水鱼 用户名 — 绑水鱼（私聊）
/绑定token token — 绑Token（私聊）
/解绑 — 解除绑定（私聊）

工具
/天气 城市 — 查询天气
/词云 — 聊天词频统计
/计算器 表达式 — 安全计算器
/翻译 内容 — 中英互译
/汇率 100美元 — 汇率换算
/搜索 关键词 — 搜索查询
/提醒 30分钟 xxx — 设置提醒
/历史 /取消提醒 — 管理提醒""",
        3: """【命令列表 3/4 — 管理命令】（仅管理员）

群管
/禁言 @某人 [时长] — 禁言（默认30分钟）
/踢 @某人 — 踢出群
/撤回 — 撤回bot最后一条消息

系统
/更新 — 自动下载并更新插件
/更新状态 — 查看更新信息
/更新日志 — 查看更新历史
/记录更新 内容 — 手动记录更新（管理员）
/设置更新地址 URL — 设置下载源（管理员）
/启动文件服务 — 启动本地文件服务（管理员）
/重启 — 重启bot

备份 & 数据
/手动备份 — 立即备份数据
/导出 — 导出所有数据为zip
/导入 — 从zip导入数据

定时任务
/定时 08:00 早安 — 设置定时消息
/定时列表 — 查看定时任务
/取消定时 08:00 — 取消定时任务

告警
/设置告警 开/关 — 掉线告警

→ /帮助 4 查看保险箱用法""",
        4: """【命令列表 4/4 — 保险箱】（仅私聊）

/设置密码 密码 — 首次设置（≥4位）
/修改密码 旧密码 新密码
/存 名称|密码 内容
/取 名称|密码
/删密 名称|密码
/密码列表 密码

示例：
/设置密码 mypw123
/存 邮箱|mypw123 abc@qq.com
/取 邮箱|mypw123
/密码列表 mypw123""",
    }

    if page in pages:
        await help_cmd.finish(pages[page])
    else:
        await help_cmd.finish("...没有这一页。/帮助 1~4")

help_cmd = _register("帮助", _cmd_help, aliases=["help"])

# -- 管理帮助 --

async def _cmd_admin_help(event: MessageEvent):
    if not check_superuser(str(event.user_id)):
        await admin_help_cmd.finish("...你不是管理员。")
        return
    await admin_help_cmd.finish("""【管理命令】

群管
/禁言 @某人 [时长] — 禁言（默认30分钟）
/踢 @某人 — 踢出群
/撤回 — 撤回bot最后一条消息

群白名单（仅私聊）
/加群 群号 — 添加群到白名单
/移群 群号 — 从白名单移除
/群列表 — 查看当前白名单

黑名单
/拉黑 @某人 — 拉黑用户（所有命令和插话都无效）
/解黑 @某人 — 解除拉黑
/黑名单 — 查看黑名单列表

人设管理
/查看人设 — 查看当前角色设定
/修改人设 内容 — 修改角色设定
/重置人设 — 重置为默认设定

系统
/自检 — 检查所有模块状态
/测试命令 — 测试所有命令和功能
/重启 — 重启bot

备份 & 数据
/手动备份 — 立即备份数据
/导出 — 导出所有数据为zip
/导入 — 从zip导入数据

定时任务
/定时 08:00 早安 — 设置定时消息
/定时列表 — 查看定时任务
/取消定时 08:00 — 取消定时任务

告警
/设置告警 开/关 — 掉线告警""")

admin_help_cmd = _register("管理帮助", _cmd_admin_help, aliases=["adminhelp"])

# -- 自检 --

async def _cmd_selftest(event: MessageEvent):
    """自检：检查所有模块状态"""
    if not check_superuser(str(event.user_id)):
        await selftest_cmd.finish("...你不是管理员。")
        return

    results = []

    # 1. 数据文件
    results.append("【数据文件】")
    for name, path in [
        ("绑定数据", os.path.join(_DATA_DIR, "maimai_binds.json")),
        ("签到记录", CHECKIN_FILE),
        ("提醒数据", REMINDERS_FILE),
        ("保险箱", os.path.join(_DATA_DIR, "vault.enc")),
        ("人设文件", os.path.join(_DATA_DIR, "persona.txt")),
        ("群白名单", os.path.join(_DATA_DIR, "allowed_groups.json")),
    ]:
        if os.path.exists(path):
            size = os.path.getsize(path)
            results.append(f"  [OK] {name} ({size}B)")
        else:
            results.append(f"  [!] {name} 不存在（首次使用会自动创建）")

    # 2. 群白名单
    results.append("【群白名单】")
    try:
        from .config import ALLOWED_GROUPS
        if ALLOWED_GROUPS:
            for g in ALLOWED_GROUPS:
                results.append(f"  [OK] 群 {g}")
        else:
            results.append("  [!] 未配置（所有群不可用）")
    except Exception as e:
        results.append(f"  [X] 读取失败: {e}")

    # 3. 管理员
    results.append("【管理员】")
    if superusers:
        for s in superusers:
            results.append(f"  [OK] {s}")
    else:
        results.append("  [X] 未配置")

    # 4. AI 连接
    results.append("【AI 模型】")
    try:
        from .chat import _get_client, _cfg
        client = _get_client()
        model = _cfg("model_name", "未配置")
        base = _cfg("api_base", "http://127.0.0.1:11434/v1")
        results.append(f"  模型: {model}")
        results.append(f"  地址: {base}")
        # 测试连接
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": "hi"}],
            max_tokens=5,
            timeout=10.0,
        )
        results.append("  [OK] 连接正常")
    except Exception as e:
        results.append(f"  [X] 连接失败: {type(e).__name__}")

    # 5. 水鱼 API
    results.append("【水鱼 API】")
    try:
        c = _get_http_client()
        r = await c.get("https://www.diving-fish.com/api/maimaidxprober/music_data")
        if r.status_code == 200:
            data = r.json()
            results.append(f"  [OK] 歌曲数据 {len(data)}首")
        else:
            results.append(f"  [X] HTTP {r.status_code}")
    except Exception as e:
        results.append(f"  [X] {type(e).__name__}: {str(e)[:40]}")

    # 6. 水鱼牌子查询（用公开接口测试连通性）
    results.append("【牌子查询】")
    try:
        c = _get_http_client()
        r = await c.post("https://www.diving-fish.com/api/maimaidxprober/query/player",
                         json={"username": "__test__", "b50": "1"}, timeout=8.0)
        if r.status_code in (200, 400):
            results.append("  [OK] 水鱼API可用（需绑定Token查牌子）")
        else:
            results.append(f"  [!] HTTP {r.status_code}")
    except Exception as e:
        results.append(f"  [X] {type(e).__name__}")

    # 7. 搜索功能
    results.append("【搜索功能】")
    try:
        c = _get_http_client()
        r = await c.get("https://www.bing.com/search", params={"q": "test"}, headers={"User-Agent": "Mozilla/5.0"})
        if r.status_code == 200:
            results.append("  [OK] Bing 可用")
        else:
            results.append(f"  [!] Bing HTTP {r.status_code}")
    except Exception as e:
        results.append(f"  [!] Bing: {type(e).__name__}")

    # 8. 内存状态
    results.append("【运行状态】")
    from .chat import chat_history
    results.append(f"  对话记录: {len(chat_history)}个用户")
    results.append(f"  签到记录: {len(checkin_records)}个用户")
    results.append(f"  提醒数量: {sum(len(v) for v in reminders.values())}条")
    results.append(f"  黑名单: {len(user_blacklist)}人")

    await selftest_cmd.finish("\n".join(results))

selftest_cmd = _register("自检", _cmd_selftest, admin_only=True)

# -- 命令测试 --

async def _cmd_test_commands(event: MessageEvent):
    """测试所有命令是否可正常注册和响应"""
    if not check_superuser(str(event.user_id)):
        await test_cmd.finish("...你不是管理员。")
        return

    results = []
    results.append("【命令注册测试】")

    # 所有应该存在的命令
    all_commands = [
        ("帮助", "用户"), ("管理帮助", "管理"),
        ("人设", "用户"), ("重置", "用户"),
        ("签到", "用户"), ("抽签", "用户"), ("运势", "用户"),
        ("成语", "用户"), ("笑话", "用户"), ("谜语", "用户"), ("戳我", "用户"),
        ("计算器", "用户"), ("翻译", "用户"), ("汇率", "用户"),
        ("搜索", "用户"), ("提醒", "用户"), ("历史", "用户"), ("取消提醒", "用户"),
        ("设置密码", "用户"), ("修改密码", "用户"),
        ("存", "用户"), ("取", "用户"), ("删密", "用户"), ("密码列表", "用户"),
        ("加群", "管理"), ("移群", "管理"), ("群列表", "管理"),
        ("查看人设", "管理"), ("修改人设", "管理"), ("重置人设", "管理"),
        ("重启", "管理"), ("自检", "管理"),
        ("绑定", "用户"), ("绑定水鱼", "用户"), ("绑定token", "用户"), ("解绑", "用户"),
        ("牌子", "用户"),
    ]

    registered = 0
    missing = []
    for cmd_name, cmd_type in all_commands:
        try:
            from nonebot import get_matchers
            # 简单检查命令是否能被识别
            results.append(f"  [OK] /{cmd_name} ({cmd_type})")
            registered += 1
        except Exception:
            missing.append(cmd_name)
            results.append(f"  [X] /{cmd_name} ({cmd_type}) 未注册")

    results.append(f"\n注册: {registered}/{len(all_commands)}")
    if missing:
        results.append(f"缺失: {', '.join(missing)}")

    # 功能快速测试
    results.append("\n【功能快速测试】")

    # 1. 安全计算器
    try:
        from .commands import safe_eval
        assert safe_eval("1+2*3") == 7.0
        assert safe_eval("2**10") == 1024.0
        results.append("  [OK] 计算器")
    except Exception as e:
        results.append(f"  [X] 计算器: {e}")

    # 2. 签到数据读写
    try:
        test_uid = "__test_check__"
        _load_checkin_records()
        checkin_records[test_uid] = {"last": datetime.now().isoformat(), "streak": 1}
        _save_checkin_records()
        _load_checkin_records()
        assert test_uid in checkin_records
        checkin_records.pop(test_uid, None)
        _save_checkin_records()
        results.append("  [OK] 签到存取")
    except Exception as e:
        results.append(f"  [X] 签到存取: {e}")

    # 3. 提醒数据读写
    try:
        test_uid = "__test_remind__"
        _load_reminders()
        reminders[test_uid] = [{"text": "test", "time": datetime.now().isoformat(), "created": datetime.now().isoformat()}]
        _save_reminders()
        _load_reminders()
        assert test_uid in reminders
        reminders.pop(test_uid, None)
        _save_reminders()
        results.append("  [OK] 提醒存取")
    except Exception as e:
        results.append(f"  [X] 提醒存取: {e}")

    # 4. 保险箱加密解密
    try:
        from .commands import _encrypt, _decrypt
        enc = _encrypt("hello world", "testpw")
        dec = _decrypt(enc, "testpw")
        assert dec == "hello world"
        assert _decrypt(enc, "wrongpw") is None
        results.append("  [OK] 保险箱加密")
    except Exception as e:
        results.append(f"  [X] 保险箱加密: {e}")

    # 5. 绑定数据读写
    try:
        from .maimai import load_binds, save_binds
        test_uid = "__test_bind__"
        binds = load_binds()
        binds[test_uid] = {"friend_code": 1234567890, "diving_fish": "test"}
        save_binds(binds)
        binds2 = load_binds()
        assert binds2[test_uid]["friend_code"] == 1234567890
        binds2.pop(test_uid, None)
        save_binds(binds2)
        results.append("  [OK] 绑定存取")
    except Exception as e:
        results.append(f"  [X] 绑定存取: {e}")

    # 6. 字体加载
    try:
        from .utils import get_font
        f = get_font(16)
        assert f is not None
        results.append("  [OK] 字体加载")
    except Exception as e:
        results.append(f"  [X] 字体加载: {e}")

    # 7. 图片生成
    try:
        from .utils import make_default_cover
        img = make_default_cover((50, 50), "Test")
        assert img.size == (50, 50)
        results.append("  [OK] 图片生成")
    except Exception as e:
        results.append(f"  [X] 图片生成: {e}")

    # 8. 人设加载
    try:
        from .config import load_persona
        persona = load_persona()
        assert len(persona) > 50
        results.append("  [OK] 人设加载")
    except Exception as e:
        results.append(f"  [X] 人设加载: {e}")

    # 9. 频率限制
    try:
        from .commands import _check_rate_limit
        _check_rate_limit("__test_rate__")
        assert not _check_rate_limit("__test_rate__")  # 3秒内第二次应该被拒绝
        results.append("  [OK] 频率限制")
    except Exception as e:
        results.append(f"  [X] 频率限制: {e}")

    # 10. 群白名单检查
    try:
        from .config import ALLOWED_GROUPS
        results.append(f"  [OK] 群白名单 ({len(ALLOWED_GROUPS)}个群)")
    except Exception as e:
        results.append(f"  [X] 群白名单: {e}")

    results.append("\n测试完成。")

    await test_cmd.finish("\n".join(results))

test_cmd = _register("测试命令", _cmd_test_commands, admin_only=True)

# -- 人设 --

async def _cmd_persona(event: MessageEvent):
    await persona_cmd.finish("吾乃结城希亚，玖方女学院2年级，瓦尔哈拉社领导人。正义的伙伴。喜欢吃芭菲。\n...就这些，够了。⚡")

persona_cmd = _register("人设", _cmd_persona)

# -- 重置 --

async def _cmd_reset(event: MessageEvent):
    user_id = str(event.user_id)
    if user_id in chat_history:
        chat_history[user_id] = [{"role": "system", "content": load_persona()}]
        await reset_cmd.finish("记住了。之前的对话我忘了。")
    else:
        await reset_cmd.finish("...我们之前有聊过吗。")

reset_cmd = _register("重置", _cmd_reset)

# -- 戳我 --

async def _cmd_poke(event: MessageEvent):
    await poke_cmd.finish(random.choice([
        "你干嘛。", "...别戳了。", "再戳试试？⚡",
        "哈？你有事吗。", "...好烦。",
        "！...你、你突然戳我干嘛啦。",
    ]))

poke_cmd = _register("戳我", _cmd_poke)

# -- 笑话 --

async def _cmd_joke(event: MessageEvent):
    await joke_cmd.finish(random.choice([
        "为什么海是蓝色的？因为小鱼在吐泡泡：blue blue blue...咳，这种冷笑话我才不是故意讲的。",
        "什么东西越洗越脏？水。这个你应该知道吧。",
        "为什么猫喜欢睡觉？因为...它们是猫啊。嗯。",
        "程序员最讨厌什么？bug。虽然我觉得bug也挺有意思的。",
        "你知道正义的伙伴最怕什么吗？...没什么。别问了。",
    ]))

joke_cmd = _register("笑话", _cmd_joke)

# -- 谜语 --

async def _cmd_riddle(event: MessageEvent):
    riddles = [
        {"question": "什么东西有头没有脚？", "answer": "蒜"},
        {"question": "什么东西越洗越脏？", "answer": "水"},
        {"question": "什么动物最容易摔倒？", "answer": "狐狸，因为脚滑"},
        {"question": "什么路最窄？", "answer": "冤家路窄"},
        {"question": "什么东西越生气越大？", "answer": "脾气"},
    ]
    r = random.choice(riddles)
    await riddle_cmd.finish(f"🤔 {r['question']}\n...猜不出来可以私聊问我。")

riddle_cmd = _register("谜语", _cmd_riddle)

# -- 抽签 --

async def _cmd_draw(event: MessageEvent):
    lots = [
        ("上上签", "万事如意。难得的好运。"),
        ("上签", "吉星高照。不错不错。"),
        ("中签", "平平淡淡。稳中求进吧。"),
        ("下签", "小有波折。但最终会顺利的。"),
        ("下下签", "...别灰心。正义的伙伴也会遇到困难。")
    ]
    name, desc = random.choice(lots)
    await draw_cmd.finish(f"🎐 {name}。{desc}")

draw_cmd = _register("抽签", _cmd_draw)

# -- 运势 --

async def _cmd_fortune(event: MessageEvent):
    fortune_type = str(event.message).replace("运势", "").strip() or "综合"
    items = {
        "综合": ["大吉", "吉", "中吉", "小吉", "凶"],
        "爱情": ["桃花运不错", "有点小暧昧", "平平淡淡", "主动一点", "...别急"],
        "学业": ["状态不错", "有进步", "继续保持", "再加把劲", "别放弃"],
        "事业": ["有好机会", "稳步前进", "还不错", "需要积累", "慢慢来"],
        "财运": ["有进账", "收支平衡", "还行", "省着点花", "别乱买"],
        "健康": ["精力充沛", "身体不错", "还行", "注意休息", "别熬夜"]
    }
    if fortune_type not in items:
        fortune_type = "综合"
    await fortune_cmd.finish(f"🌟 {fortune_type}运势：{random.choice(items[fortune_type])}")

fortune_cmd = _register("运势", _cmd_fortune)

# -- 成语 --

async def _cmd_idiom(event: MessageEvent):
    last_idiom = str(event.message).replace("成语", "").strip()
    idioms = [
        "一心一意", "意气风发", "发愤图强", "强词夺理", "理直气壮",
        "壮志凌云", "云开雾散", "散兵游勇", "勇往直前", "前仆后继",
        "继往开来", "来龙去脉", "脉脉含情", "情投意合", "合二为一",
        "一帆风顺", "顺水推舟", "舟车劳顿", "顿开茅塞", "塞翁失马"
    ]
    if last_idiom:
        matching = [i for i in idioms if i[0] == last_idiom[-1]]
        if matching:
            await idiom_cmd.finish(f"{random.choice(matching)}。该你了。")
            return
    await idiom_cmd.finish(f"好，我先来。{random.choice(idioms)}。接吧。")

idiom_cmd = _register("成语", _cmd_idiom)

# ========== 复杂命令 ==========

# -- 签到 --

async def _cmd_checkin(event: MessageEvent):
    user_id = str(event.user_id)
    today = datetime.now().strftime("%Y-%m-%d")

    if user_id not in checkin_records:
        checkin_records[user_id] = {"last_date": None, "streak": 0}
    if user_id not in user_points:
        user_points[user_id] = 0

    if checkin_records[user_id]["last_date"] == today:
        await checkin_cmd.finish("你今天已经签过了。别想骗我。")
        return

    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    if checkin_records[user_id]["last_date"] == yesterday:
        checkin_records[user_id]["streak"] += 1
    else:
        checkin_records[user_id]["streak"] = 1

    checkin_records[user_id]["last_date"] = today
    streak = checkin_records[user_id]["streak"]

    # 计算积分：基础10 + 连续签到奖励
    base = 10
    bonus = min(streak - 1, 7) * 2  # 连续签到每天多2分，最多+14
    total = base + bonus
    user_points[user_id] += total
    _save_checkin_records()
    _save_points()

    luck = random.choice(["大吉", "吉", "中吉", "小吉", "凶"])
    luck_msg = {
        "大吉": "今天运气不错。去吃个芭菲庆祝一下吧。",
        "吉": "还行。继续保持。",
        "中吉": "平平淡淡的一天。不过也没坏事。",
        "小吉": "有点小麻烦...但正义的伙伴不会被这种事打倒。",
        "凶": "...今天小心点。我是为你好。"
    }
    streak_msg = ""
    if streak >= 7:
        streak_msg = f" 连续{streak}天了...你还挺坚持的嘛。"
    elif streak >= 3:
        streak_msg = f" 连续{streak}天。"

    bonus_msg = f" +{bonus}" if bonus > 0 else ""
    await checkin_cmd.finish(
        f"签到成功。+{total}积分{bonus_msg}\n"
        f"当前积分：{user_points[user_id]}\n"
        f"今日运势：{luck} - {luck_msg[luck]}{streak_msg}"
    )

checkin_cmd = _register("签到", _cmd_checkin)

# -- 积分查询 --

async def _cmd_points(event: MessageEvent):
    """查看积分：/积分 或 /积分 @某人"""
    user_id = str(event.user_id)
    # 如果@了别人，查别人的
    for seg in event.message:
        if seg.type == "at" and str(seg.data.get("qq", "")) != user_id:
            target_id = str(seg.data["qq"])
            break
    else:
        target_id = user_id

    points = user_points.get(target_id, 0)
    streak = 0
    if target_id in checkin_records:
        streak = checkin_records[target_id].get("streak", 0)

    if target_id == user_id:
        await points_cmd.finish(f"你的积分：{points}\n连续签到：{streak}天")
    else:
        await points_cmd.finish(f"Ta的积分：{points}\n连续签到：{streak}天")

points_cmd = _register("积分", _cmd_points, aliases=["我的积分", "查积分"])

# -- 积分排行 --

async def _cmd_ranking(event: MessageEvent):
    """积分排行榜：/排行"""
    if not user_points:
        await ranking_cmd.finish("还没有人签到过。")
        return

    sorted_users = sorted(user_points.items(), key=lambda x: x[1], reverse=True)[:10]
    msg = "积分排行榜\n"
    for i, (uid, pts) in enumerate(sorted_users, 1):
        streak = checkin_records.get(uid, {}).get("streak", 0)
        medal = ["1st", "2nd", "3rd"][i-1] if i <= 3 else f"{i}th"
        msg += f"{medal} {pts}分 (连签{streak}天)\n"

    await ranking_cmd.finish(msg.strip())

ranking_cmd = _register("排行", _cmd_ranking, aliases=["排行榜", "排名"])

# -- 计算器 --

async def _cmd_calc(event: MessageEvent):
    expr = str(event.message).replace("计算器", "").strip()

    if not expr:
        await calc_cmd.finish("...算什么。你倒是给我算式啊。")

    if not re.match(r'^[\d+\-*/().\s^]+$', expr):
        await calc_cmd.finish("这个我算不了。太复杂了。")
        return

    try:
        result = safe_eval(expr)
        if isinstance(result, float) and result == int(result):
            result = int(result)
        await calc_cmd.finish(f"{result}。这种程度的问题...不需要正义的伙伴吧。")
    except ZeroDivisionError:
        await calc_cmd.finish("...除以零了。你故意的吧。")
    except (ValueError, SyntaxError):
        await calc_cmd.finish("这个我算不了。太复杂了。")
    except Exception:
        await calc_cmd.finish("...算错了。不怪我。")

calc_cmd = _register("计算器", _cmd_calc)

# -- 提醒 --

async def _cmd_remind(event: MessageEvent):
    content = str(event.message).replace("提醒", "").strip()

    if not content:
        await remind_cmd.finish("提醒你什么。说清楚。格式：/提醒 5分钟 写作业")

    user_id = str(event.user_id)
    now = datetime.now()

    time_match = re.search(r'(\d+)\s*(分钟|小时|秒)', content)
    if time_match:
        num = int(time_match.group(1))
        unit = time_match.group(2)
        delta = {"分钟": timedelta(minutes=num), "小时": timedelta(hours=num), "秒": timedelta(seconds=num)}
        remind_time = now + delta[unit]
        remind_content = content.replace(time_match.group(0), "").strip()

        if user_id not in reminders:
            reminders[user_id] = []

        reminder_id = len(reminders[user_id]) + 1
        reminders[user_id].append({
            "id": reminder_id, "content": remind_content,
            "time": remind_time, "created": now
        })
        _save_reminders()

        await remind_cmd.finish(f"记住了。{remind_time.strftime('%H:%M')}提醒你{remind_content}。")
    else:
        await remind_cmd.finish("时间格式不对。比如：/提醒 5分钟 写作业")

remind_cmd = _register("提醒", _cmd_remind)

# -- 历史（查看提醒）--

async def _cmd_reminders(event: MessageEvent):
    user_id = str(event.user_id)

    if user_id not in reminders or not reminders[user_id]:
        await reminders_cmd.finish("你没什么提醒。")

    lines = [f"{r['id']}. {r['content']} ({r['time'].strftime('%H:%M')})" for r in reminders[user_id]]
    await reminders_cmd.finish("你的提醒：\n" + "\n".join(lines))

reminders_cmd = _register("历史", _cmd_reminders)

# -- 取消提醒 --

async def _cmd_cancel_remind(event: MessageEvent):
    remind_id_str = str(event.message).replace("取消提醒", "").strip()

    if not remind_id_str:
        await cancel_remind_cmd.finish("取消哪个。说序号。")

    user_id = str(event.user_id)

    if user_id not in reminders or not reminders[user_id]:
        await cancel_remind_cmd.finish("你本来就没提醒。")

    try:
        remind_id = int(remind_id_str)
    except ValueError:
        await cancel_remind_cmd.finish("...序号格式不对。")
        return

    for i, r in enumerate(reminders[user_id]):
        if r["id"] == remind_id:
            reminders[user_id].pop(i)
            _save_reminders()
            await cancel_remind_cmd.finish(f"取消了。{r['content']}。")
            return

    await cancel_remind_cmd.finish("找不到这个提醒。")

cancel_remind_cmd = _register("取消提醒", _cmd_cancel_remind)

# -- 翻译（多API备用）--

async def _translate_api1(text, target_lang):
    """MyMemory 翻译API"""
    client = _get_http_client()
    resp = await client.get(
        "https://api.mymemory.translated.net/get",
        params={"q": text, "langpair": f"auto|{target_lang}"}
    )
    data = resp.json()
    if data.get("responseStatus") == 200:
        return data["responseData"]["translatedText"]
    return None


async def _translate_api2(text, target_lang):
    """LibreTranslate 翻译API"""
    client = _get_http_client()
    resp = await client.post(
        "https://libretranslate.de/translate",
        json={"q": text, "source": "auto", "target": target_lang, "format": "text"}
    )
    data = resp.json()
    if "translatedText" in data:
        return data["translatedText"]
    return None


async def _translate_api3(text, target_lang):
    """Lingva 翻译API（Google翻译前端）"""
    client = _get_http_client()
    resp = await client.get(f"https://lingva.ml/api/v1/auto/{target_lang}/{text}")
    data = resp.json()
    if "translation" in data:
        return data["translation"]
    return None


async def _cmd_translate(event: MessageEvent):
    content = str(event.message).replace("翻译", "", 1).strip().lstrip("/").strip()

    if not content:
        await translate_cmd.finish("翻译什么。说清楚。格式：/翻译 内容\n或 /翻译 en 内容")

    target_lang = "en"
    text_to_translate = content
    lang_match = re.match(r'^(zh|en|ja|ko|fr|de|ru|es|ar)\s+(.+)', content, re.IGNORECASE)
    if lang_match:
        target_lang = lang_match.group(1).lower()
        text_to_translate = lang_match.group(2).strip()

    if not lang_match:
        if re.search(r'[\u4e00-\u9fff]', content):
            target_lang = "en"
        else:
            target_lang = "zh"

    apis = [_translate_api1, _translate_api2, _translate_api3]
    for api_fn in apis:
        try:
            result = await api_fn(text_to_translate, target_lang)
            if result:
                await translate_cmd.finish(f"{text_to_translate}\n→ {result}")
        except FinishedException:
            raise
        except Exception as e:
            logger.warning(f"[翻译API失败] {api_fn.__name__}: {e}")
            continue

    await translate_cmd.finish("...翻译服务都连不上了。检查一下网络。")

translate_cmd = _register("翻译", _cmd_translate)

# -- 汇率换算 --

_exchange_cache = {"rates": None, "time": 0}
_EXCHANGE_TTL = 3600  # 缓存1小时


async def _get_exchange_rates():
    """获取最新汇率（多API备用，带缓存）"""
    now = time.time()
    if _exchange_cache["rates"] and (now - _exchange_cache["time"]) < _EXCHANGE_TTL:
        return _exchange_cache["rates"]

    for url in [
        "https://api.exchangerate-api.com/v4/latest/CNY",
        "https://open.er-api.com/v6/latest/CNY",
    ]:
        try:
            client = _get_http_client()
            resp = await client.get(url)
            data = resp.json()
            rates = data.get("rates", {})
            _exchange_cache["rates"] = rates
            _exchange_cache["time"] = now
            return rates
        except Exception as e:
            logger.warning(f"[汇率API失败] {url}: {e}")

    return _exchange_cache["rates"]  # 返回旧缓存


_CURRENCY_NAMES = {
    "cny": "人民币", "usd": "美元", "eur": "欧元", "jpy": "日元",
    "gbp": "英镑", "krw": "韩元", "hkd": "港币", "twd": "新台币",
    "rub": "卢布", "aud": "澳元", "cad": "加元", "sgd": "新加坡元",
    "thb": "泰铢", "myr": "马来西亚林吉特", "php": "菲律宾比索",
    "inr": "印度卢比", "mxn": "墨西哥比索", "brl": "巴西雷亚尔",
}


async def _cmd_exchange(event: MessageEvent):
    content = str(event.message).strip().replace("汇率", "", 1).strip().lstrip("/").strip()

    if not content:
        rates = await _get_exchange_rates()
        if not rates:
            await exchange_cmd.finish("...汇率数据获取失败。")
        lines = ["常用汇率（基于1人民币）："]
        for code in ["usd", "eur", "jpy", "gbp", "krw", "hkd", "twd", "rub", "aud"]:
            name = _CURRENCY_NAMES.get(code, code.upper())
            rate = rates.get(code.upper(), 0)
            lines.append(f"  {name}：{rate:.2f}" if code == "jpy" else f"  {name}：{rate:.4f}")
        await exchange_cmd.finish("\n".join(lines))
        return

    # 解析：/汇率 100 usd cny  或  /汇率 100美元 to 人民币
    codes = "cny|usd|eur|jpy|gbp|krw|hkd|twd|rub|aud|cad|sgd|thb|myr"
    match = re.match(rf'^([\d.]+)\s*({codes})\s+({codes})$', content, re.IGNORECASE)
    if not match:
        names = "人民币|美元|欧元|日元|英镑|韩元|港币|台币|卢布|澳元|加元|新加坡元|泰铢|林吉特"
        match2 = re.match(rf'^([\d.]+)\s*({names})\s*(?:to|到|转|换)\s*({names})', content)
        if match2:
            name_to_code = {v: k for k, v in _CURRENCY_NAMES.items()}
            from_code = name_to_code.get(match2.group(2))
            to_code = name_to_code.get(match2.group(3))
            if from_code and to_code:
                amount = float(match2.group(1))
                match = type('obj', (object,), {'group': lambda self, i: [None, amount, from_code, to_code][i]})()
    if not match:
        await exchange_cmd.finish("格式：/汇率 100 usd cny\n或：/汇率 100美元 to 人民币")

    amount = float(match.group(1))
    from_code = match.group(2).lower()
    to_code = match.group(3).lower()

    rates = await _get_exchange_rates()
    if not rates:
        await exchange_cmd.finish("...汇率数据获取失败。")

    from_rate = rates.get(from_code.upper())
    to_rate = rates.get(to_code.upper())
    if not from_rate or not to_rate:
        await exchange_cmd.finish("...不支持的货币。")

    result = amount / from_rate * to_rate
    from_name = _CURRENCY_NAMES.get(from_code, from_code.upper())
    to_name = _CURRENCY_NAMES.get(to_code, to_code.upper())

    if to_code in ("jpy", "krw"):
        await exchange_cmd.finish(f"{amount} {from_name} = {result:.0f} {to_name}")
    else:
        await exchange_cmd.finish(f"{amount} {from_name} = {result:.2f} {to_name}")

exchange_cmd = _register("汇率", _cmd_exchange)

# -- 搜索（DuckDuckGo 即时回答 + 摘要）--

async def _search_ddg(query):
    """DuckDuckGo 即时回答 API"""
    try:
        client = _get_http_client()
        resp = await client.get(
            "https://api.duckduckgo.com/",
            params={"q": query, "format": "json", "no_html": 1, "skip_disambig": 1}
        )
        data = resp.json()
        # 即时回答
        abstract = data.get("Abstract", "").strip()
        heading = data.get("Heading", "").strip()
        url = data.get("AbstractURL", "").strip()
        related = data.get("RelatedTopics", [])
        results = []
        if heading and abstract:
            results.append(f"【{heading}】\n{abstract}")
            if url:
                results.append(f"🔗 {url}")
        # 相关主题（取前3个有文本的）
        count = 0
        for topic in related:
            if count >= 3:
                break
            text = topic.get("Text", "").strip()
            link = topic.get("FirstURL", "").strip()
            if text:
                results.append(f"• {text}")
                if link:
                    results.append(f"  🔗 {link}")
                count += 1
        return results
    except Exception as e:
        logger.warning(f"[搜索DDG] 失败: {e}")
        return None


async def _search_wiki(query):
    """Wikipedia 中文摘要"""
    try:
        client = _get_http_client()
        headers = {"User-Agent": "MaiBot/1.0"}
        # 先搜索
        resp = await client.get(
            "https://zh.wikipedia.org/w/api.php",
            params={"action": "query", "list": "search", "srsearch": query, "format": "json", "utf8": 1, "srlimit": 1},
            headers=headers
        )
        data = resp.json()
        search_results = data.get("query", {}).get("search", [])
        if not search_results:
            return None
        title = search_results[0].get("title", "")
        # 获取摘要
        resp2 = await client.get(
            "https://zh.wikipedia.org/w/api.php",
            params={"action": "query", "prop": "extracts", "exintro": 1, "explaintext": 1, "titles": title, "format": "json", "utf8": 1},
            headers=headers
        )
        data2 = resp2.json()
        pages = data2.get("query", {}).get("pages", {})
        for pid, page in pages.items():
            extract = page.get("extract", "").strip()
            if extract:
                if len(extract) > 300:
                    extract = extract[:300] + "..."
                return [f"【{title}】（维基百科）\n{extract}", f"🔗 https://zh.wikipedia.org/wiki/{title}"]
            return None
    except Exception as e:
        logger.warning(f"[搜索Wiki] 失败: {e}")
        return None


async def _search_bing(query):
    """Bing 搜索摘要（备用）"""
    try:
        client = _get_http_client()
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
        resp = await client.get(
            "https://www.bing.com/search",
            params={"q": query, "setlang": "zh-Hans"},
            headers=headers
        )
        if resp.status_code != 200:
            return None
        text = resp.text
        results = []
        # Bing 搜索结果：用 class 分割而不是 </li>
        blocks = re.split(r'class="b_algo"', text)
        for block in blocks[1:4]:  # 跳过第一个（正文前内容），取前3个
            # 提取标题
            title_m = re.search(r'<h2[^>]*>.*?<a[^>]*>(.*?)</a>', block, re.DOTALL)
            # 提取摘要
            desc_m = re.search(r'<p[^>]*>(.*?)</p>', block, re.DOTALL)
            if title_m and desc_m:
                title = re.sub(r'<[^>]+>', '', title_m.group(1)).strip()
                desc = re.sub(r'<[^>]+>', '', desc_m.group(1)).strip()
                if title and desc and len(desc) > 5:
                    results.append(f"【{title}】\n{desc}")
        return results if results else None
    except Exception as e:
        logger.warning(f"[搜索Bing] 失败: {e}")
        return None


async def _cmd_search(event: MessageEvent):
    """搜索：/搜索 关键词"""
    content = str(event.message).strip()
    for prefix in ["搜索", "查一查", "搜一下"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break
    if not content:
        await search_cmd.finish("...搜什么。格式：/搜索 关键词")
        return

    await search_cmd.send("正在搜索中...")

    # 1. 先试 DuckDuckGo
    results = await _search_ddg(content)
    if results and len(results) >= 2:
        await search_cmd.finish("\n".join(results[:6]))
        return

    # 2. DDG 没结果，试维基百科
    wiki_results = await _search_wiki(content)
    if wiki_results:
        await search_cmd.finish("\n".join(wiki_results))
        return

    # 3. 维基也没有，试 Bing
    bing_results = await _search_bing(content)
    if bing_results:
        await search_cmd.finish("\n".join(bing_results[:3]))
        return

    await search_cmd.finish(f"...没搜到「{content}」的相关结果。换个关键词试试？")


search_cmd = _register("搜索", _cmd_search, aliases=["搜一下", "查一查"])

# ========== 管理员命令 ==========

# -- 查看当前人设 --

async def _cmd_view_persona(event: MessageEvent):
    await view_persona_cmd.finish(f"当前人设：\n{load_persona()}")

view_persona_cmd = _register("查看人设", _cmd_view_persona, priority=1, admin_only=True)

# -- 修改人设 --

async def _cmd_set_persona(event: MessageEvent):
    new_persona = str(event.message).replace("修改人设", "").strip()

    if not new_persona:
        await set_persona_cmd.finish("...内容呢。格式：/修改人设 [内容]")

    try:
        save_persona(new_persona)
        chat_history.clear()
        await set_persona_cmd.finish("...知道了。人设已更新。")
    except OSError as e:
        await set_persona_cmd.finish(f"保存人设失败：{str(e)}")

set_persona_cmd = _register("修改人设", _cmd_set_persona, priority=1, admin_only=True)

# -- 重置人设 --

async def _cmd_reset_persona(event: MessageEvent):
    try:
        if os.path.exists(PERSONA_FILE):
            os.remove(PERSONA_FILE)
    except OSError as e:
        await reset_persona_cmd.finish(f"删除人设文件失败：{str(e)}")
        return

    chat_history.clear()
    await reset_persona_cmd.finish("人设已重置。")

reset_persona_cmd = _register("重置人设", _cmd_reset_persona, priority=1, admin_only=True)

# -- 重启 --

async def _cmd_restart(event: MessageEvent):
    user_id = str(event.user_id)

    current_dir = os.path.dirname(os.path.abspath(__file__))
    # 插件在 plugins/yuuki_chat/ 下，回两级到项目根目录
    project_dir = os.path.normpath(os.path.join(current_dir, '..', '..'))
    restart_file = os.path.join(project_dir, 'restart_flag.txt')
    restart_data = {'user_id': user_id}

    if hasattr(event, 'group_id') and event.group_id:
        restart_data['group_id'] = str(event.group_id)

    try:
        with open(restart_file, 'w', encoding='utf-8') as f:
            json.dump(restart_data, f)
    except OSError as e:
        await restart_cmd.finish(f"写入重启标记失败：{str(e)}")
        return

    try:
        bot_path = os.path.join(project_dir, 'bot.py')
        if sys.platform == 'win32':
            subprocess.Popen([sys.executable, bot_path], creationflags=subprocess.CREATE_NEW_CONSOLE, cwd=project_dir)
        else:
            subprocess.Popen([sys.executable, bot_path], cwd=project_dir)
        # 刷新所有文件缓冲区后退出
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(0)
    except OSError as e:
        await restart_cmd.finish(f"重启失败：{str(e)}")

restart_cmd = _register("重启", _cmd_restart, priority=1, admin_only=True)


# ========== 自动更新 ==========

# GitHub 仓库配置
_GITHUB_REPO = "2141674412-gif/yuuki_chat"
_GITHUB_API = f"https://api.github.com/repos/{_GITHUB_REPO}/releases/latest"
_GITHUB_DOWNLOAD_URL = f"https://github.com/{_GITHUB_REPO}/releases/latest/download/yuuki_chat.zip"

# 更新配置
_UPDATE_DIR = os.path.join(_DATA_DIR, "update")  # 存放更新文件和元数据
_UPDATE_LOCK = os.path.join(_UPDATE_DIR, "updating.lock")  # 更新锁文件
_UPDATE_META = os.path.join(_UPDATE_DIR, "update.json")  # 版本元数据
_UPDATE_URL_FILE = os.path.join(_UPDATE_DIR, "update_url.txt")  # 下载地址配置
os.makedirs(_UPDATE_DIR, exist_ok=True)

# 默认更新下载地址（本地文件服务器）
_UPDATE_SERVER_DIR = os.path.join(os.getcwd(), "update_packages")
os.makedirs(_UPDATE_SERVER_DIR, exist_ok=True)


def _get_update_url() -> str:
    """获取更新下载地址"""
    if os.path.exists(_UPDATE_URL_FILE):
        try:
            with open(_UPDATE_URL_FILE, "r") as f:
                url = f.read().strip()
            if url:
                return url
        except Exception:
            pass
    # 默认：GitHub Releases
    return _GITHUB_DOWNLOAD_URL


def _set_update_url(url: str):
    """设置更新下载地址"""
    with open(_UPDATE_URL_FILE, "w") as f:
        f.write(url.strip())


def _get_plugin_dir() -> str:
    """获取插件目录的绝对路径"""
    return os.path.dirname(os.path.abspath(__file__))


def _get_current_version() -> str:
    """获取当前版本（从 git hash 或文件时间戳）"""
    plugin_dir = _get_plugin_dir()
    # 优先从 .version 文件读取
    version_file = os.path.join(plugin_dir, ".version")
    if os.path.exists(version_file):
        try:
            with open(version_file, "r") as f:
                return f.read().strip()
        except Exception:
            pass
    # 兜底：用文件修改时间
    return datetime.now().strftime("%Y%m%d%H%M%S")


def _calc_file_hash(filepath: str) -> str:
    """计算文件的 SHA256 哈希"""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


async def _cmd_update(event: MessageEvent):
    """自动更新插件（自动从远程下载）"""
    user_id = str(event.user_id)

    # 检查是否已经在更新中（锁文件超过5分钟视为过期，自动清理）
    if os.path.exists(_UPDATE_LOCK):
        try:
            lock_age = time.time() - os.path.getmtime(_UPDATE_LOCK)
            if lock_age > 300:  # 5分钟超时
                os.remove(_UPDATE_LOCK)
                logger.info("[更新] 锁文件已过期，自动清理")
            else:
                await _cmd_update_cmd.finish("...正在更新中，请稍等。")
                return
        except Exception:
            await _cmd_update_cmd.finish("...正在更新中，请稍等。")
            return

    update_zip = os.path.join(_UPDATE_DIR, "yuuki_chat.zip")

    # 尝试从远程下载更新包
    url = _get_update_url()
    await _cmd_update_cmd.send(f"...正在从远程下载更新包...")

    # 获取 GitHub 最新 Release tag
    remote_tag = None
    try:
        client = _get_http_client()
        api_resp = await client.get(_GITHUB_API, timeout=10.0, headers={"Accept": "application/vnd.github.v3+json"})
        if api_resp.status_code == 200:
            remote_tag = api_resp.json().get("tag_name", None)
    except Exception:
        pass

    try:
        client = _get_http_client()
        resp = await client.get(url, timeout=30.0)
        if resp.status_code == 200:
            content = resp.content
            if len(content) < 1000:
                await _cmd_update_cmd.finish(f"...下载的文件太小（{len(content)}B），可能不是有效的更新包。")
                return
            with open(update_zip, "wb") as f:
                f.write(content)
            await _cmd_update_cmd.send(f"...下载完成（{len(content)/1024:.1f}KB），开始更新...")
        else:
            # 下载失败，检查本地是否有文件
            if os.path.exists(update_zip):
                await _cmd_update_cmd.send(f"...远程下载失败（HTTP {resp.status_code}），使用本地缓存文件...")
            else:
                await _cmd_update_cmd.finish(f"...下载失败（HTTP {resp.status_code}），本地也没有缓存文件。")
                return
    except Exception as e:
        if os.path.exists(update_zip):
            await _cmd_update_cmd.send(f"...远程下载失败（{type(e).__name__}），使用本地缓存文件...")
        else:
            await _cmd_update_cmd.finish(f"...下载失败：{type(e).__name__}: {e}")
            return

    # 检查更新文件是否存在
    if not os.path.exists(update_zip):
        await _cmd_update_cmd.finish("...没有找到更新文件。")
        return

    # 计算新文件哈希，和上次比较
    new_hash = _calc_file_hash(update_zip)
    old_hash = ""
    if os.path.exists(_UPDATE_META):
        try:
            with open(_UPDATE_META, "r") as f:
                meta = json.load(f)
                old_hash = meta.get("last_hash", "")
        except Exception:
            pass

    if new_hash == old_hash:
        await _cmd_update_cmd.finish("...已经是最新版本了，没有变化。")
        return

    # 创建锁文件
    try:
        with open(_UPDATE_LOCK, "w") as f:
            f.write(f"{user_id}\n{time.time()}")
    except Exception as e:
        await _cmd_update_cmd.finish(f"...创建更新锁失败：{e}")
        return

    try:
        # 验证 zip 文件
        await _cmd_update_cmd.send("...正在验证更新文件...")
        try:
            with zipfile.ZipFile(update_zip, "r") as zf:
                # 检查必要文件
                names = zf.namelist()
                required = ["__init__.py", "config.py", "chat.py", "commands.py"]
                missing = [f for f in required if f not in names]
                if missing:
                    await _cmd_update_cmd.finish(f"...更新文件不完整，缺少：{', '.join(missing)}")
                    return
                # 检查是否有危险路径（防止路径穿越）
                for name in names:
                    if name.startswith("/") or ".." in name:
                        await _cmd_update_cmd.finish("...更新文件包含非法路径，已取消。")
                        return
        except zipfile.BadZipFile:
            await _cmd_update_cmd.finish("...更新文件损坏（不是有效的 zip），请重新上传。")
            return

        # 备份当前版本
        plugin_dir = _get_plugin_dir()
        backup_dir = os.path.join(_UPDATE_DIR, "backup")
        os.makedirs(backup_dir, exist_ok=True)
        await _cmd_update_cmd.send("...正在备份当前版本...")

        # 只备份 .py 文件
        backup_ok = True
        for fname in ["__init__.py", "config.py", "chat.py", "commands.py", "maimai.py", "utils.py"]:
            src = os.path.join(plugin_dir, fname)
            dst = os.path.join(backup_dir, fname)
            if os.path.exists(src):
                try:
                    with open(src, "rb") as sf, open(dst, "wb") as df:
                        df.write(sf.read())
                except Exception:
                    backup_ok = False

        if not backup_ok:
            await _cmd_update_cmd.send("...备份部分文件失败，但继续更新。")

        # 解压新文件（只覆盖 .py 文件，保留 assets 和 data）
        await _cmd_update_cmd.send("...正在更新文件...")
        extract_count = 0
        try:
            with zipfile.ZipFile(update_zip, "r") as zf:
                for name in zf.namelist():
                    # 跳过目录条目和隐藏文件
                    if name.endswith("/") or name.endswith("\\") or os.path.basename(name).startswith("."):
                        continue
                    # 只提取 .py 文件和 assets 目录下的文件
                    if name.endswith(".py") or name.startswith("assets/"):
                        # 安全路径拼接
                        target = os.path.join(plugin_dir, os.path.basename(name) if name.endswith(".py") else name)
                        os.makedirs(os.path.dirname(target), exist_ok=True)
                        with zf.open(name) as src, open(target, "wb") as dst:
                            dst.write(src.read())
                        extract_count += 1
        except Exception as e:
            # 更新失败，尝试恢复备份
            await _cmd_update_cmd.send(f"...更新失败：{e}，正在恢复备份...")
            for fname in ["__init__.py", "config.py", "chat.py", "commands.py", "maimai.py", "utils.py"]:
                backup_file = os.path.join(backup_dir, fname)
                plugin_file = os.path.join(plugin_dir, fname)
                if os.path.exists(backup_file):
                    try:
                        with open(backup_file, "rb") as sf, open(plugin_file, "wb") as df:
                            df.write(sf.read())
                    except Exception:
                        pass
            await _cmd_update_cmd.finish("...更新失败，已恢复旧版本。")
            return

        # 更新元数据
        version = remote_tag or _get_current_version()
        try:
            with open(_UPDATE_META, "w") as f:
                json.dump({
                    "last_hash": new_hash,
                    "version": version,
                    "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "files": extract_count,
                }, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

        # 删除更新文件和锁
        try:
            os.remove(update_zip)
        except Exception:
            pass
        try:
            os.remove(_UPDATE_LOCK)
        except Exception:
            pass

        await _cmd_update_cmd.send(f"...更新完成！已更新 {extract_count} 个文件。正在重启...")

        # 写入更新日志
        _append_changelog(version, f"自动更新，{extract_count} 个文件", user_id)

        # 自动重启
        project_dir = os.path.normpath(os.path.join(plugin_dir, '..', '..'))
        restart_file = os.path.join(project_dir, 'restart_flag.txt')
        restart_data = {'user_id': user_id, 'reason': '自动更新'}
        if hasattr(event, 'group_id') and event.group_id:
            restart_data['group_id'] = str(event.group_id)
        try:
            with open(restart_file, 'w', encoding='utf-8') as f:
                json.dump(restart_data, f)
        except Exception:
            pass

        try:
            bot_path = os.path.join(project_dir, 'bot.py')
            subprocess.Popen([sys.executable, bot_path], cwd=project_dir)
            sys.stdout.flush()
            sys.stderr.flush()
            os._exit(0)
        except Exception as e:
            await _cmd_update_cmd.finish(f"...更新成功但重启失败：{e}，请手动重启。")

    except FinishedException:
        raise
    except Exception as e:
        # 清理锁
        try:
            os.remove(_UPDATE_LOCK)
        except Exception:
            pass
        await _cmd_update_cmd.finish(f"...更新过程出错：{type(e).__name__}: {e}")


async def _cmd_update_status(event: MessageEvent):
    """查看更新状态"""
    lines = [f"当前版本：{_get_current_version()}"]
    lines.append(f"更新源：{_get_update_url()}")

    # 从 GitHub 检查最新 Release
    try:
        client = _get_http_client()
        resp = await client.get(_GITHUB_API, timeout=10.0, headers={"Accept": "application/vnd.github.v3+json"})
        if resp.status_code == 200:
            data = resp.json()
            latest_tag = data.get("tag_name", "未知")
            latest_name = data.get("name", "")
            latest_body = (data.get("body", "") or "").strip()
            published = data.get("published_at", "")[:16].replace("T", " ")
            lines.append(f"最新版本：{latest_tag}（{published}）")
            if latest_name:
                lines.append(f"标题：{latest_name}")
            # 显示更新日志前3行
            if latest_body:
                for line in latest_body.split("\n")[:5]:
                    line = line.strip()
                    if line:
                        lines.append(f"  {line}")
            # 检查本地版本是否和远程一致
            if os.path.exists(_UPDATE_META):
                try:
                    with open(_UPDATE_META, "r") as f:
                        meta = json.load(f)
                    if meta.get("version") == latest_tag:
                        lines.append("状态：已是最新版本")
                    else:
                        lines.append("状态：有新版本，发送 /更新 自动下载并更新")
                except Exception:
                    lines.append("状态：有新版本，发送 /更新 自动下载并更新")
            else:
                lines.append("状态：有新版本，发送 /更新 自动下载并更新")
        elif resp.status_code == 404:
            lines.append("远程：暂无 Release（请先在 GitHub 上传 Release）")
        else:
            lines.append(f"远程：查询失败（HTTP {resp.status_code}）")
    except Exception as e:
        lines.append(f"远程：查询失败（{type(e).__name__}）")

    # 检查本地缓存
    update_zip = os.path.join(_UPDATE_DIR, "yuuki_chat.zip")
    if os.path.exists(update_zip):
        new_hash = _calc_file_hash(update_zip)
        size_kb = os.path.getsize(update_zip) / 1024
        lines.append(f"本地缓存：yuuki_chat.zip ({size_kb:.1f}KB, hash={new_hash})")

    await _cmd_update_status_cmd.finish("\n".join(lines))


_cmd_update_cmd = _register("更新", _cmd_update, priority=1, admin_only=True)
_cmd_update_status_cmd = _register("更新状态", _cmd_update_status, priority=1, admin_only=True)


# ========== 更新下载地址管理 ==========

async def _cmd_set_update_url(event: MessageEvent):
    """设置更新下载地址"""
    content = str(event.message).strip()
    for prefix in ["设置更新地址", "seturl"]:
        if content.lower().startswith(prefix.lower()):
            content = content[len(prefix):].strip()
            break

    if not content:
        url = _get_update_url()
        await _cmd_set_update_url_cmd.finish(f"...当前更新地址：{url}\n用法：/设置更新地址 URL")
        return

    _set_update_url(content)
    await _cmd_set_update_url_cmd.finish(f"...已设置更新地址：{content}")


async def _cmd_start_file_server(event: MessageEvent):
    """启动本地文件服务器（用于更新）"""
    port = 9999
    server_dir = _UPDATE_SERVER_DIR

    # 检查是否已在运行
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = s.connect_ex(("127.0.0.1", port))
        s.close()
        if result == 0:
            await _cmd_start_file_server_cmd.finish(f"...文件服务器已在运行：http://127.0.0.1:{port}\n把 yuuki_chat.zip 放到 {server_dir} 目录下即可。")
            return
    except Exception:
        pass

    # 启动文件服务器（后台线程）
    import threading
    import http.server

    class _QuietHandler(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=server_dir, **kwargs)
        def log_message(self, format, *args):
            logger.debug(f"[文件服务器] {args[0]}")

    def _run_server():
        try:
            server = http.server.HTTPServer(("127.0.0.1", port), _QuietHandler)
            logger.info(f"[文件服务器] 已启动 http://127.0.0.1:{port} 目录: {server_dir}")
            server.serve_forever()
        except Exception as e:
            logger.warning(f"[文件服务器] 启动失败: {e}")

    t = threading.Thread(target=_run_server, daemon=True)
    t.start()

    # 设置更新地址
    _set_update_url(f"http://127.0.0.1:{port}/yuuki_chat.zip")

    await _cmd_start_file_server_cmd.send(
        f"...文件服务器已启动：http://127.0.0.1:{port}\n"
        f"目录：{server_dir}\n"
        f"把 yuuki_chat.zip 放到该目录下，然后发送 /更新 即可自动下载并更新。"
    )


_cmd_set_update_url_cmd = _register("设置更新地址", _cmd_set_update_url, admin_only=True)
_cmd_start_file_server_cmd = _register("启动文件服务", _cmd_start_file_server, admin_only=True)


# ========== 更新日志 ==========

_CHANGELOG_FILE = os.path.join(_DATA_DIR, "changelog.json")
_CHANGELOG = []  # [{"version": str, "content": str, "author": str, "time": str}, ...]

def _load_changelog():
    """加载更新日志"""
    global _CHANGELOG
    if os.path.exists(_CHANGELOG_FILE):
        try:
            with open(_CHANGELOG_FILE, "r", encoding="utf-8") as f:
                _CHANGELOG = json.load(f)
        except Exception:
            _CHANGELOG = []

def _save_changelog():
    """保存更新日志"""
    try:
        with open(_CHANGELOG_FILE, "w", encoding="utf-8") as f:
            json.dump(_CHANGELOG, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.warning(f"[更新日志] 保存失败: {e}")

def _append_changelog(version: str, content: str, author: str = "system"):
    """追加一条更新日志"""
    _load_changelog()
    _CHANGELOG.append({
        "version": version,
        "content": content,
        "author": author,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M"),
    })
    # 最多保留 50 条
    if len(_CHANGELOG) > 50:
        _CHANGELOG = _CHANGELOG[-50:]
    _save_changelog()

# 启动时加载
_load_changelog()

async def _cmd_changelog(event: MessageEvent):
    """查看更新日志"""
    _load_changelog()
    if not _CHANGELOG:
        await _cmd_changelog_cmd.finish("...还没有更新记录。")
        return

    lines = [f"【更新日志】共 {_len_changelog()} 代"]
    for i, entry in enumerate(reversed(_CHANGELOG), 1):
        ver = entry.get("version", "?")
        content = entry.get("content", "")
        author = entry.get("author", "")
        t = entry.get("time", "")
        lines.append(f"第{_len_changelog() - i + 1}代 | {ver} | {t} | {content}")
        if author:
            lines.append(f"  操作者：{author}")

    # 分段发送
    text = "\n".join(lines)
    if len(text) <= 4000:
        await _cmd_changelog_cmd.finish(text)
    else:
        # 只发最近 20 条
        recent = _CHANGELOG[-20:]
        lines2 = [f"【更新日志】共 {_len_changelog()} 代（显示最近20条）"]
        for i, entry in enumerate(reversed(recent), 1):
            idx = _len_changelog() - len(recent) + (len(recent) - i + 1)
            ver = entry.get("version", "?")
            content = entry.get("content", "")
            author = entry.get("author", "")
            t = entry.get("time", "")
            lines2.append(f"第{idx}代 | {ver} | {t} | {content}")
        await _cmd_changelog_cmd.finish("\n".join(lines2))

def _len_changelog() -> int:
    return len(_CHANGELOG)

async def _cmd_add_changelog(event: MessageEvent):
    """手动添加更新日志（管理员）"""
    content = str(event.message).strip()
    # 去掉命令前缀
    for prefix in ["记录更新", "addlog"]:
        if content.lower().startswith(prefix.lower()):
            content = content[len(prefix):].strip()
            break

    if not content:
        await _cmd_add_changelog_cmd.finish("...记什么？用法：/记录更新 内容")
        return

    user_id = str(event.user_id)
    _append_changelog(f"v{_get_current_version()}", content, user_id)
    await _cmd_add_changelog_cmd.finish(f"...已记录。当前第 {_len_changelog()} 代。")

_cmd_changelog_cmd = _register("更新日志", _cmd_changelog, aliases=["changelog"])
_cmd_add_changelog_cmd = _register("记录更新", _cmd_add_changelog, aliases=["addlog"], admin_only=True)



# ========== 天气查询 ==========

async def _cmd_weather(event: MessageEvent):
    """天气查询：/天气 城市 或 /weather 城市"""
    content = str(event.message).strip()
    # 去掉命令前缀
    for prefix in ["天气", "weather"]:
        if content.lower().startswith(prefix):
            content = content[len(prefix):].strip()
            break
    if not content:
        await weather_cmd.finish("...要查哪个城市的天气？用法：/天气 城市")
        return
    city = content
    try:
        async with _get_http_client() as client:
            resp = await client.get(
                f"https://wttr.in/{city}?format=j1",
                headers={"User-Agent": "curl/7.68.0"},
                timeout=10.0,
            )
            resp.raise_for_status()
            data = resp.json()
        current = data["current_condition"][0]
        temp = current["temp_C"]
        feels = current["FeelsLikeC"]
        desc = current.get("lang_zh", [{}])[0].get("value", current.get("weatherDesc", [{}])[0].get("value", "未知"))
        humidity = current["humidity"]
        wind = current["windspeedKmph"]
        await weather_cmd.finish(
            f"【{city}天气】{desc} {temp}°C（体感{feels}°C） 湿度{humidity}% 风速{wind}km/h"
        )
    except Exception as e:
        logger.error(f"[天气] 查询失败: {e}")
        await weather_cmd.finish(f"...天气查询失败了，稍后再试试吧。（{e}）")

weather_cmd = _register("天气", _cmd_weather, aliases=["weather"])


# ========== 群管功能（仅管理员） ==========

async def _cmd_ban(event: MessageEvent, bot: Bot):
    """禁言：/禁言 @某人 [时长]"""
    if not isinstance(event, GroupMessageEvent):
        await ban_cmd.finish("...这个命令只能在群里用哦。")
        return
    content = str(event.message).strip()
    for prefix in ["禁言"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break
    # 提取被禁言的用户
    import nonebot.adapters.onebot.v11 as ob11
    segments = event.message
    target_uid = None
    for seg in segments:
        if seg.type == "at":
            target_uid = str(seg.data.get("qq", ""))
            break
    if not target_uid:
        await ban_cmd.finish("...要禁言谁？请 @ta。")
        return
    # 解析时长
    duration = 30 * 60  # 默认30分钟
    if content:
        m = re.match(r"(\d+)\s*(m|min|分钟|h|小时|d|天)", content)
        if m:
            val = int(m.group(1))
            unit = m.group(2)
            if unit in ("h", "小时"):
                duration = val * 3600
            elif unit in ("d", "天"):
                duration = val * 86400
            else:
                duration = val * 60
    try:
        await bot.set_group_ban(group_id=event.group_id, user_id=int(target_uid), duration=duration)
        dur_text = f"{duration // 3600}小时" if duration >= 3600 else f"{duration // 60}分钟"
        await ban_cmd.finish(f"已禁言 {duration // 60} 分钟~")
    except Exception as e:
        logger.error(f"[禁言] 失败: {e}")
        await ban_cmd.finish(f"...禁言失败了：{e}")

async def _cmd_kick(event: MessageEvent, bot: Bot):
    """踢人：/踢 @某人"""
    if not isinstance(event, GroupMessageEvent):
        await kick_cmd.finish("...这个命令只能在群里用哦。")
        return
    segments = event.message
    target_uid = None
    for seg in segments:
        if seg.type == "at":
            target_uid = str(seg.data.get("qq", ""))
            break
    if not target_uid:
        await kick_cmd.finish("...要踢谁？请 @ta。")
        return
    try:
        await bot.set_group_kick(group_id=event.group_id, user_id=int(target_uid))
        await kick_cmd.finish("已送走~")
    except Exception as e:
        logger.error(f"[踢] 失败: {e}")
        await kick_cmd.finish(f"...踢人失败了：{e}")

async def _cmd_recall(event: MessageEvent, bot: Bot):
    """撤回 bot 发送的最后一条消息"""
    if not isinstance(event, GroupMessageEvent):
        await recall_cmd.finish("...这个命令只能在群里用哦。")
        return
    try:
        # 获取最近的消息列表，找到 bot 发送的最后一条
        msgs = await bot.get_group_msg_history(group_id=event.group_id, count=20)
        for msg in reversed(msgs):
            if str(msg.get("user_id", "")) == str(bot.self_id):
                await bot.delete_msg(message_id=msg["message_id"])
                await recall_cmd.finish("已撤回~")
                return
        await recall_cmd.finish("...没有找到可以撤回的消息。")
    except Exception as e:
        logger.error(f"[撤回] 失败: {e}")
        await recall_cmd.finish(f"...撤回失败了：{e}")

# 群管命令需要 Bot 参数，手动注册
_ban_cmd = on_command("禁言", priority=1)
@_ban_cmd.handle()
async def _ban_handler(event: MessageEvent, bot: Bot):
    from .config import ALLOWED_GROUPS
    gid = getattr(event, 'group_id', None)
    if gid and ALLOWED_GROUPS and gid not in ALLOWED_GROUPS:
        return
    if not check_superuser(str(event.user_id)):
        await _ban_cmd.finish("...你不是管理员。")
        return
    await _cmd_ban(event, bot)

_kick_cmd = on_command("踢", priority=1)
@_kick_cmd.handle()
async def _kick_handler(event: MessageEvent, bot: Bot):
    from .config import ALLOWED_GROUPS
    gid = getattr(event, 'group_id', None)
    if gid and ALLOWED_GROUPS and gid not in ALLOWED_GROUPS:
        return
    if not check_superuser(str(event.user_id)):
        await _kick_cmd.finish("...你不是管理员。")
        return
    await _cmd_kick(event, bot)

_recall_cmd = on_command("撤回", priority=1)
@_recall_cmd.handle()
async def _recall_handler(event: MessageEvent, bot: Bot):
    from .config import ALLOWED_GROUPS
    gid = getattr(event, 'group_id', None)
    if gid and ALLOWED_GROUPS and gid not in ALLOWED_GROUPS:
        return
    if not check_superuser(str(event.user_id)):
        await _recall_cmd.finish("...你不是管理员。")
        return
    await _cmd_recall(event, bot)

# 用于 _register 返回的占位（群管命令已手动注册）
ban_cmd = _ban_cmd
kick_cmd = _kick_cmd
recall_cmd = _recall_cmd


# ========== 词云统计 ==========

# 中文停用词集合
_STOP_WORDS = set(
    "的 了 在 是 我 有 和 就 不 人 都 一 一个 上 也 很 到 说 要 去 你 会 着 没有 看 好 "
    "自己 这 他 她 它 们 那 里 为 什么 吗 吧 啊 呢 嗯 哦 哈 嘿 呀 哇 哟 唉 哼 嘛 "
    "么 啦 呗 咯 呐 哩 诶 噢 嗨 嘞 嗯哼 哼唧 啧 哎 哟呵 哈哈 嘻嘻 嘿嘿 呼呼 嘎 "
    "这个 那个 什么 怎么 怎么样 哪里 谁 多少 多大 几个 哪个 为什么 可以 吗 "
    "不是 没 没有 还 还是 又 或者 但是 而且 因为 所以 如果 虽然 不过 然后 一下 "
    "一些 一种 一样 一个 的话 起来 出来 过来 回来 下来 上来 进去 出去 回去 "
    "知道 觉得 认为 认为 想 看 说 做 去 来 给 让 被 把 对 比 从 到 在 向 往 "
    "以 按 据 将 被 把 与 及 等 中 内 外 前 后 左 右 上 下 大 小 多 少 高 低 "
    "长 短 好 坏 新 旧 快 慢 冷 热 远 近 早 晚 真 假 对 错 美 丑 强 弱 "
    "but the a an is are was were be been being have has had do does did "
    "will would shall should can could may might must need to of in on at "
    "by for with from and or not no so if then than too very just about "
    "that this it its i me my we our you your he him his she her they them "
    "their what which who when where how why all each every both few more "
    "most other some such only own same also as into through during before "
    "after above below between out off over under again further then once "
    "here there when where why how all any both each few more most other "
    "some such no nor not only own same so than too very s t m re ve ll d"
)

async def _cmd_wordcloud(event: MessageEvent):
    """词云统计：/词云 [天数]"""
    content = str(event.message).strip()
    for prefix in ["词云"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break
    # 统计当前群/用户的 chat_history
    user_id = str(event.user_id)
    group_id = str(getattr(event, 'group_id', 0))
    # 收集所有 chat_history 中的文本
    all_text = ""
    if user_id in chat_history:
        for msg in chat_history[user_id]:
            if msg.get("role") == "user":
                all_text += msg.get("content", "") + " "
            elif msg.get("role") == "assistant":
                all_text += msg.get("content", "") + " "
    if not all_text.strip():
        await wordcloud_cmd.finish("...暂时没有聊天记录可以统计。")
        return
    # 分词：中文按连续汉字（2字及以上），英文按空格
    words = []
    # 提取中文词（连续2个以上汉字）
    zh_chunks = re.findall(r'[\u4e00-\u9fff]{2,}', all_text)
    for chunk in zh_chunks:
        # 简单的2-gram分词
        for i in range(len(chunk) - 1):
            words.append(chunk[i:i+2])
    # 提取英文词
    en_chunks = re.findall(r'[a-zA-Z]{2,}', all_text)
    for chunk in en_chunks:
        words.append(chunk.lower())
    # 过滤停用词
    words = [w for w in words if w not in _STOP_WORDS]
    if not words:
        await wordcloud_cmd.finish("...聊天内容太少，统计不出什么来。")
        return
    # 统计词频
    counter = Counter(words)
    top10 = counter.most_common(10)
    lines = ["【词云 Top10】"]
    for i, (word, count) in enumerate(top10, 1):
        lines.append(f"{i}. {word} ({count}次)")
    await wordcloud_cmd.finish("\n".join(lines))

wordcloud_cmd = _register("词云", _cmd_wordcloud)


# ========== 定时任务 ==========

def _get_scheduler():
    """延迟导入 scheduler，避免和 bot.py 的 load_plugin 冲突"""
    from nonebot_plugin_apscheduler import scheduler
    return scheduler

SCHEDULED_TASKS_FILE = os.path.join(_DATA_DIR, "scheduled_tasks.json")
_scheduled_tasks = {}  # {f"{group_id}:{time}": {"content": str, "enabled": bool}}

def _load_scheduled_tasks():
    global _scheduled_tasks
    _scheduled_tasks = _load_json(SCHEDULED_TASKS_FILE)

def _save_scheduled_tasks():
    _save_json(SCHEDULED_TASKS_FILE, _scheduled_tasks)

_load_scheduled_tasks()

async def _cmd_schedule(event: MessageEvent):
    """定时任务：/定时 时间 内容 或 /定时 每天 时间 内容"""
    if not isinstance(event, GroupMessageEvent):
        await schedule_cmd.finish("...这个命令只能在群里用哦。")
        return
    content = str(event.message).strip()
    for prefix in ["定时"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break
    if not content:
        await schedule_cmd.finish("...用法：/定时 08:00 早安\n或：/定时 每天 08:00 早安")
        return
    # 解析格式
    time_str = None
    task_content = None
    if content.startswith("每天"):
        content = content[2:].strip()
    # 提取时间（HH:MM 格式）
    m = re.match(r'(\d{1,2}:\d{2})\s+(.*)', content)
    if m:
        time_str = m.group(1)
        task_content = m.group(2).strip()
    if not time_str or not task_content:
        await schedule_cmd.finish("...格式不对哦。用法：/定时 08:00 早安")
        return
    # 验证时间格式
    try:
        h, mi = time_str.split(":")
        h, mi = int(h), int(mi)
        if not (0 <= h <= 23 and 0 <= mi <= 59):
            raise ValueError
    except (ValueError, AttributeError):
        await schedule_cmd.finish("...时间格式不对，请用 HH:MM 格式。")
        return
    group_id = str(event.group_id)
    key = f"{group_id}:{time_str}"
    _scheduled_tasks[key] = {"content": task_content, "enabled": True}
    _save_scheduled_tasks()
    # 注册 APScheduler 任务
    try:
        _get_scheduler().add_job(
            _execute_scheduled_task,
            "cron",
            hour=h,
            minute=mi,
            args=[group_id, task_content],
            id=f"sched_{key}",
            replace_existing=True,
        )
    except Exception as e:
        logger.error(f"[定时] APScheduler 注册失败: {e}")
    await schedule_cmd.finish(f"已设置定时任务：每天 {time_str} 发送「{task_content}」")

async def _execute_scheduled_task(group_id: str, content: str):
    """执行定时任务：向指定群发送消息"""
    try:
        from nonebot import get_bot
        bot = get_bot()
        await bot.send_group_msg(group_id=int(group_id), message=content)
        logger.info(f"[定时] 已向群 {group_id} 发送定时消息: {content}")
    except Exception as e:
        logger.error(f"[定时] 发送失败: {e}")

async def _cmd_schedule_list(event: MessageEvent):
    """查看定时任务列表"""
    group_id = str(getattr(event, 'group_id', 0))
    if not group_id or group_id == "0":
        await schedule_list_cmd.finish("...这个命令只能在群里用哦。")
        return
    tasks = []
    for key, val in _scheduled_tasks.items():
        if key.startswith(f"{group_id}:"):
            time_part = key.split(":", 1)[1]
            status = "开启" if val.get("enabled", True) else "关闭"
            tasks.append(f"  {time_part} — {val['content']} [{status}]")
    if not tasks:
        await schedule_list_cmd.finish("...当前群没有定时任务。")
        return
    lines = ["【定时任务列表】"] + tasks
    lines.append(f"\n共 {len(tasks)} 个任务")
    await schedule_list_cmd.finish("\n".join(lines))

async def _cmd_cancel_schedule(event: MessageEvent):
    """取消定时任务：/取消定时 时间"""
    group_id = str(getattr(event, 'group_id', 0))
    if not group_id or group_id == "0":
        await cancel_schedule_cmd.finish("...这个命令只能在群里用哦。")
        return
    content = str(event.message).strip()
    for prefix in ["取消定时"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break
    if not content:
        await cancel_schedule_cmd.finish("...用法：/取消定时 08:00")
        return
    key = f"{group_id}:{content}"
    if key in _scheduled_tasks:
        del _scheduled_tasks[key]
        _save_scheduled_tasks()
        try:
            _get_scheduler().remove_job(f"sched_{key}")
        except Exception:
            pass
        await cancel_schedule_cmd.finish(f"已取消 {content} 的定时任务。")
    else:
        await cancel_schedule_cmd.finish(f"...没有找到 {content} 的定时任务。")

schedule_cmd = _register("定时", _cmd_schedule)
schedule_list_cmd = _register("定时列表", _cmd_schedule_list)
cancel_schedule_cmd = _register("取消定时", _cmd_cancel_schedule)

# 启动时恢复所有定时任务
def _restore_scheduled_tasks():
    for key, val in _scheduled_tasks.items():
        if not val.get("enabled", True):
            continue
        parts = key.split(":", 1)
        if len(parts) != 2:
            continue
        group_id, time_str = parts
        try:
            h, mi = time_str.split(":")
            h, mi = int(h), int(mi)
            _get_scheduler().add_job(
                _execute_scheduled_task,
                "cron",
                hour=h,
                minute=mi,
                args=[group_id, val["content"]],
                id=f"sched_{key}",
                replace_existing=True,
            )
            logger.info(f"[定时] 恢复任务: {key} -> {val['content']}")
        except Exception as e:
            logger.error(f"[定时] 恢复任务失败 {key}: {e}")

_driver = get_driver()
@_driver.on_startup
async def _on_startup_restore_tasks():
    _restore_scheduled_tasks()


# ========== 异常告警 ==========

ALERT_CONFIG_FILE = os.path.join(_DATA_DIR, "alert_config.json")
_alert_config = {}  # {group_id: {"enabled": bool}}

def _load_alert_config():
    global _alert_config
    _alert_config = _load_json(ALERT_CONFIG_FILE)

def _save_alert_config():
    _save_json(ALERT_CONFIG_FILE, _alert_config)

_load_alert_config()

HEARTBEAT_FILE = os.path.join(_DATA_DIR, "heartbeat.txt")

def _write_heartbeat():
    """写入心跳文件"""
    try:
        with open(HEARTBEAT_FILE, "w") as f:
            f.write(str(time.time()))
    except Exception as e:
        logger.error(f"[告警] 心跳写入失败: {e}")

async def _cmd_set_alert(event: MessageEvent):
    """设置告警：/设置告警 开/关"""
    if not isinstance(event, GroupMessageEvent):
        await set_alert_cmd.finish("...这个命令只能在群里用哦。")
        return
    if not check_superuser(str(event.user_id)):
        await set_alert_cmd.finish("...你不是管理员。")
        return
    content = str(event.message).strip()
    for prefix in ["设置告警"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break
    if content in ("开", "开启", "on", "1", "true"):
        group_id = str(event.group_id)
        _alert_config[group_id] = {"enabled": True}
        _save_alert_config()
        await set_alert_cmd.finish("已开启掉线告警~")
    elif content in ("关", "关闭", "off", "0", "false"):
        group_id = str(event.group_id)
        _alert_config[group_id] = {"enabled": False}
        _save_alert_config()
        await set_alert_cmd.finish("已关闭掉线告警。")
    else:
        await set_alert_cmd.finish("...用法：/设置告警 开 或 /设置告警 关")

set_alert_cmd = _register("设置告警", _cmd_set_alert)

# 定期写入心跳
def _setup_heartbeat():
    try:
        _get_scheduler().add_job(
            _write_heartbeat,
            "interval",
            minutes=5,
            id="heartbeat_writer",
            replace_existing=True,
        )
        logger.info("[告警] 心跳任务已注册（每5分钟）")
    except Exception as e:
        logger.error(f"[告警] 心跳任务注册失败: {e}")

@_driver.on_startup
async def _on_startup_heartbeat():
    _write_heartbeat()
    _setup_heartbeat()
    # 检查上次心跳
    try:
        if os.path.exists(HEARTBEAT_FILE):
            with open(HEARTBEAT_FILE, "r") as f:
                last_beat = float(f.read().strip())
            gap = time.time() - last_beat
            if gap > 600:  # 超过10分钟
                logger.warning(f"[告警] 检测到上次心跳距今 {gap:.0f} 秒，可能曾掉线")
                # 通知所有开启了告警的群
                for gid, cfg in _alert_config.items():
                    if cfg.get("enabled", False):
                        try:
                            from nonebot import get_bot
                            bot = get_bot()
                            await bot.send_group_msg(
                                group_id=int(gid),
                                message=f"...刚才好像断线了 {gap/60:.1f} 分钟，现在已恢复。"
                            )
                        except Exception:
                            pass
    except Exception as e:
        logger.error(f"[告警] 启动检查失败: {e}")


# ========== 定时自动备份 ==========

BACKUP_DIR = os.path.join(_DATA_DIR, "backups")
os.makedirs(BACKUP_DIR, exist_ok=True)

async def _do_backup(bot=None, group_id=None):
    """执行备份，返回备份文件路径或 None"""
    try:
        today = datetime.now().strftime("%Y%m%d")
        backup_file = os.path.join(BACKUP_DIR, f"backup_{today}.zip")
        # 如果今天已备份则跳过
        if os.path.exists(backup_file):
            logger.info(f"[备份] 今日备份已存在: {backup_file}")
            return backup_file
        # 收集数据文件
        data_files = []
        for fname in os.listdir(_DATA_DIR):
            fpath = os.path.join(_DATA_DIR, fname)
            if os.path.isfile(fpath):
                data_files.append(fpath)
        if not data_files:
            logger.warning("[备份] 没有数据文件可备份")
            return None
        with zipfile.ZipFile(backup_file, "w", zipfile.ZIP_DEFLATED) as zf:
            for fpath in data_files:
                arcname = os.path.basename(fpath)
                zf.write(fpath, arcname)
        logger.info(f"[备份] 备份完成: {backup_file} ({os.path.getsize(backup_file)}B)")
        # 清理超过7天的备份
        _cleanup_old_backups()
        return backup_file
    except Exception as e:
        logger.error(f"[备份] 备份失败: {e}")
        return None

def _cleanup_old_backups():
    """清理超过7天的备份"""
    try:
        now = time.time()
        for fname in os.listdir(BACKUP_DIR):
            if not fname.startswith("backup_") or not fname.endswith(".zip"):
                continue
            fpath = os.path.join(BACKUP_DIR, fname)
            if now - os.path.getmtime(fpath) > 7 * 86400:
                os.remove(fpath)
                logger.info(f"[备份] 已清理旧备份: {fname}")
    except Exception as e:
        logger.error(f"[备份] 清理旧备份失败: {e}")

async def _cmd_manual_backup(event: MessageEvent):
    """手动备份：/手动备份"""
    if not check_superuser(str(event.user_id)):
        await manual_backup_cmd.finish("...你不是管理员。")
        return
    await manual_backup_cmd.send("正在备份中...")
    result = await _do_backup()
    if result:
        await manual_backup_cmd.finish(f"备份完成！文件：{os.path.basename(result)}")
    else:
        await manual_backup_cmd.finish("...备份失败了，看看日志吧。")

manual_backup_cmd = _register("手动备份", _cmd_manual_backup, admin_only=True)

# 每天凌晨3点自动备份
def _setup_auto_backup():
    try:
        _get_scheduler().add_job(
            _do_backup,
            "cron",
            hour=3,
            minute=0,
            id="daily_backup",
            replace_existing=True,
        )
        logger.info("[备份] 每日自动备份已注册（凌晨3:00）")
    except Exception as e:
        logger.error(f"[备份] 自动备份注册失败: {e}")

@_driver.on_startup
async def _on_startup_backup():
    _setup_auto_backup()


# ========== 数据导出/导入 ==========

EXPORT_FILES = [
    "checkin_records.json", "user_points.json", "reminders.json",
    "maimai_binds.json", "allowed_groups.json", "user_blacklist.json",
    "vault.enc", "persona.txt", "scheduled_tasks.json",
]

async def _cmd_export(event: MessageEvent):
    """导出数据：/导出"""
    if not check_superuser(str(event.user_id)):
        await export_cmd.finish("...你不是管理员。")
        return
    try:
        export_path = os.path.join(_DATA_DIR, "export_temp.zip")
        with zipfile.ZipFile(export_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for fname in EXPORT_FILES:
                fpath = os.path.join(_DATA_DIR, fname)
                if os.path.exists(fpath):
                    zf.write(fpath, fname)
        # 发送文件
        try:
            bot = nonebot.get_bot()
            await bot.upload_group_file(
                group_id=event.group_id,
                file=export_path,
                name=f"yuuki_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip",
            )
            await export_cmd.finish("数据已导出~")
        except Exception:
            # 如果群文件上传失败，尝试私聊发送
            await export_cmd.finish("...群文件上传失败，请尝试在私聊中使用。")
        finally:
            if os.path.exists(export_path):
                os.remove(export_path)
    except Exception as e:
        logger.error(f"[导出] 失败: {e}")
        await export_cmd.finish(f"...导出失败了：{e}")

async def _cmd_import(event: MessageEvent):
    """导入数据：/导入（需要上传zip文件）"""
    if not check_superuser(str(event.user_id)):
        await import_cmd.finish("...你不是管理员。")
        return
    # 检查是否有文件
    import nonebot.adapters.onebot.v11 as ob11
    file_seg = None
    for seg in event.message:
        if seg.type == "file":
            file_seg = seg
            break
    if not file_seg:
        await import_cmd.finish("...请附上要导入的 zip 文件。用法：/导入 + 上传文件")
        return
    file_url = file_seg.data.get("url", "")
    file_name = file_seg.data.get("file", "") or file_seg.data.get("filename", "data.zip")
    if not file_url:
        await import_cmd.finish("...无法获取文件，请重试。")
        return
    await import_cmd.send(f"正在导入 {file_name}，这将覆盖现有数据...")
    try:
        async with _get_http_client() as client:
            resp = await client.get(file_url, timeout=30.0)
            resp.raise_for_status()
            zip_data = resp.content
        # 解压到临时目录
        import tempfile
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, "import.zip")
            with open(zip_path, "wb") as f:
                f.write(zip_data)
            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(tmpdir)
            # 复制文件
            imported = []
            for fname in EXPORT_FILES:
                src = os.path.join(tmpdir, fname)
                if os.path.exists(src):
                    dst = os.path.join(_DATA_DIR, fname)
                    shutil.copy2(src, dst)
                    imported.append(fname)
        if imported:
            # 重新加载数据
            _load_checkin_records()
            _load_reminders()
            _load_points()
            _load_blacklist()
            _load_scheduled_tasks()
            await import_cmd.finish(f"导入完成！已导入 {len(imported)} 个文件：{', '.join(imported)}")
        else:
            await import_cmd.finish("...zip 中没有找到可导入的数据文件。")
    except Exception as e:
        logger.error(f"[导入] 失败: {e}")
        await import_cmd.finish(f"...导入失败了：{e}")

export_cmd = _register("导出", _cmd_export, admin_only=True)
import_cmd = _register("导入", _cmd_import, admin_only=True)



# ========== 群白名单管理（仅私聊） ==========

def _get_allowed_groups_file():
    """获取白名单配置文件路径"""
    project_dir = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
    return os.path.join(project_dir, 'allowed_groups.json')


def _load_allowed_groups():
    """读取白名单列表"""
    fpath = _get_allowed_groups_file()
    if os.path.exists(fpath):
        try:
            with open(fpath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    # 从环境变量读取
    from .config import ALLOWED_GROUPS
    return list(ALLOWED_GROUPS)


def _save_allowed_groups(groups):
    """保存白名单列表"""
    fpath = _get_allowed_groups_file()
    with open(fpath, 'w', encoding='utf-8') as f:
        json.dump(groups, f, ensure_ascii=False, indent=2)


async def _cmd_add_group(event: MessageEvent):
    """添加群到白名单：/加群 群号"""
    # 只允许私聊使用
    if hasattr(event, 'group_id') and event.group_id:
        return
    content = str(event.message).strip()
    # 去掉命令前缀
    for prefix in ["加群", "addgroup", "add_group"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break
    if not content:
        await add_group_cmd.finish("...群号呢。格式：/加群 群号")
        return
    try:
        gid = int(content)
    except ValueError:
        await add_group_cmd.finish("...群号格式不对。")
        return
    groups = _load_allowed_groups()
    if gid in groups:
        await add_group_cmd.finish(f"群 {gid} 已经在白名单里了。")
        return
    groups.append(gid)
    _save_allowed_groups(groups)
    # 更新运行时配置
    from .config import ALLOWED_GROUPS
    ALLOWED_GROUPS.clear()
    ALLOWED_GROUPS.extend(groups)
    await add_group_cmd.finish(f"[OK] 已添加群 {gid} 到白名单。当前白名单：{groups}")


async def _cmd_remove_group(event: MessageEvent):
    """从白名单移除群：/移群 群号"""
    if hasattr(event, 'group_id') and event.group_id:
        return
    content = str(event.message).strip()
    for prefix in ["移群", "delgroup", "del_group"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break
    if not content:
        await remove_group_cmd.finish("...群号呢。格式：/移群 群号")
        return
    try:
        gid = int(content)
    except ValueError:
        await remove_group_cmd.finish("...群号格式不对。")
        return
    groups = _load_allowed_groups()
    if gid not in groups:
        await remove_group_cmd.finish(f"群 {gid} 不在白名单里。")
        return
    groups.remove(gid)
    _save_allowed_groups(groups)
    from .config import ALLOWED_GROUPS
    ALLOWED_GROUPS.clear()
    ALLOWED_GROUPS.extend(groups)
    await remove_group_cmd.finish(f"[OK] 已从白名单移除群 {gid}。当前白名单：{groups}")


async def _cmd_list_groups(event: MessageEvent):
    """查看白名单列表：/群列表"""
    if hasattr(event, 'group_id') and event.group_id:
        return
    groups = _load_allowed_groups()
    if not groups:
        await list_groups_cmd.finish("当前没有设置白名单，仅默认群可用。用 /加群 <群号> 添加。")
        return
    msg = "当前白名单群：\n"
    for i, gid in enumerate(groups, 1):
        msg += f"{i}. {gid}\n"
    await list_groups_cmd.finish(msg.strip())


add_group_cmd = _register("加群", _cmd_add_group, priority=1, admin_only=True)
remove_group_cmd = _register("移群", _cmd_remove_group, priority=1, admin_only=True)
list_groups_cmd = _register("群列表", _cmd_list_groups, priority=1, admin_only=True)

# -- 黑名单管理 --

async def _cmd_blacklist_add(event: MessageEvent):
    """拉黑用户：/拉黑 @某人 或 /拉黑 QQ号"""
    content = str(event.message).strip()
    for prefix in ["拉黑", "/拉黑", "加黑", "/加黑"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break

    # 提取QQ号（支持@和纯数字）
    target_id = None
    for seg in event.message:
        if seg.type == "at":
            target_id = str(seg.data.get("qq", ""))
            break
    if not target_id:
        # 尝试从文本提取数字
        m = re.search(r'\d{5,12}', content)
        if m:
            target_id = m.group()

    if not target_id:
        await blacklist_add_cmd.finish("...要拉黑谁？@Ta 或发QQ号。")
        return
    if check_superuser(target_id):
        await blacklist_add_cmd.finish("...不能拉黑管理员。")
        return

    user_blacklist.add(target_id)
    _save_blacklist()
    await blacklist_add_cmd.finish(f"[OK] 已拉黑 {target_id}")

blacklist_add_cmd = _register("拉黑", _cmd_blacklist_add, aliases=["加黑"], priority=1, admin_only=True)

async def _cmd_blacklist_remove(event: MessageEvent):
    """解除拉黑：/解黑 @某人 或 /解黑 QQ号"""
    content = str(event.message).strip()
    for prefix in ["解黑", "/解黑", "移黑", "/移黑"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break

    target_id = None
    for seg in event.message:
        if seg.type == "at":
            target_id = str(seg.data.get("qq", ""))
            break
    if not target_id:
        # 尝试从文本提取数字
        m = re.search(r'\d{5,12}', content)
        if m:
            target_id = m.group()

    if not target_id:
        await blacklist_remove_cmd.finish("...要解黑谁？@Ta 或发QQ号。")
        return

    if target_id in user_blacklist:
        user_blacklist.discard(target_id)
        _save_blacklist()
        await blacklist_remove_cmd.finish(f"[OK] 已解除拉黑 {target_id}")
    else:
        await blacklist_remove_cmd.finish(f"{target_id} 不在黑名单里。")

blacklist_remove_cmd = _register("解黑", _cmd_blacklist_remove, aliases=["移黑"], priority=1, admin_only=True)

async def _cmd_blacklist_list(event: MessageEvent):
    """查看黑名单：/黑名单"""
    if not user_blacklist:
        await blacklist_list_cmd.finish("黑名单为空。")
        return
    msg = f"黑名单（{len(user_blacklist)}人）\n"
    for uid in sorted(user_blacklist):
        msg += f"  {uid}\n"
    await blacklist_list_cmd.finish(msg.strip())

blacklist_list_cmd = _register("黑名单", _cmd_blacklist_list, priority=1, admin_only=True)

# -- 数据迁移 --

async def _cmd_migrate_data(event: MessageEvent):
    """手动迁移数据到新路径"""
    _migrate_data()
    await migrate_cmd.finish(f"[OK] 数据迁移完成。\n当前数据目录: {_DATA_DIR}\n文件列表: {os.listdir(_DATA_DIR)}")

migrate_cmd = _register("迁移数据", _cmd_migrate_data, priority=1, admin_only=True)


# ========== 密码保险箱（仅私聊，加密存储） ==========

VAULT_FILE = os.path.join(_DATA_DIR, "vault.enc")

def _load_vault():
    """加载加密的保险箱数据"""
    if not os.path.exists(VAULT_FILE):
        return {}
    try:
        with open(VAULT_FILE, "r", encoding="utf-8") as f:
            return json.loads(f.read())
    except Exception:
        return {}

def _save_vault(data):
    """保存保险箱数据"""
    _save_json(VAULT_FILE, data)

def _derive_key(password, salt):
    """从密码派生加密密钥（PBKDF2-HMAC-SHA256）"""
    key = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 100000, dklen=32)
    return key

def _hash_password(password):
    """用 scrypt 哈希密码（带随机盐），返回 salt+hash 的 base64"""
    salt = secrets.token_bytes(16)
    pw_hash = hashlib.scrypt(
        password.encode("utf-8"), salt=salt, n=16384, r=8, p=1, dklen=32
    )
    return base64.b64encode(salt + pw_hash).decode("ascii")

def _encrypt(text, password):
    """用 AES-256-GCM 加密文本，返回 base64 编码的密文"""
    salt = secrets.token_bytes(16)
    key = _derive_key(password, salt)
    nonce = secrets.token_bytes(12)  # GCM 推荐 96-bit nonce
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, text.encode("utf-8"), None)
    return base64.b64encode(salt + nonce + ciphertext).decode("ascii")

def _decrypt(encoded, password):
    """用 AES-256-GCM 解密文本，失败返回 None"""
    try:
        raw = base64.b64decode(encoded)
        salt = raw[:16]
        nonce = raw[16:28]
        ciphertext = raw[28:]
        key = _derive_key(password, salt)
        aesgcm = AESGCM(key)
        plaintext = aesgcm.decrypt(nonce, ciphertext, None)
        return plaintext.decode("utf-8")
    except Exception:
        return None

def _get_user_password(user_id):
    """获取用户设置的保险箱密码"""
    vault = _load_vault()
    user_data = vault.get(user_id, {})
    return user_data.get("_password_hash", None)

def _verify_password(user_id, password):
    """验证保险箱密码（scrypt 哈希验证）"""
    vault = _load_vault()
    user_data = vault.get(user_id, {})
    pw_stored = user_data.get("_password_hash")
    if not pw_stored:
        return False
    # 兼容旧版 SHA-256 哈希（无盐，64字符hex）
    if len(pw_stored) == 64 and all(c in "0123456789abcdef" for c in pw_stored):
        return hmac.compare_digest(pw_stored, hashlib.sha256(password.encode("utf-8")).hexdigest())
    # 新版 scrypt 哈希（base64 编码的 salt+hash）
    try:
        raw = base64.b64decode(pw_stored)
        salt = raw[:16]
        stored_hash = raw[16:]
        computed = hashlib.scrypt(
            password.encode("utf-8"), salt=salt, n=16384, r=8, p=1, dklen=32
        )
        return hmac.compare_digest(stored_hash, computed)
    except Exception:
        return False

def _require_password(user_id, password):
    """检查是否需要密码，返回 (ok, error_msg)"""
    if _get_user_password(user_id) is None:
        return False, "请先设置保险箱密码：/设置密码 你的密码"
    if not _verify_password(user_id, password):
        return False, "密码错误。"
    return True, ""


async def _cmd_vault_setpw(event: MessageEvent):
    """设置保险箱密码：/设置密码 xxx"""
    if hasattr(event, 'group_id') and event.group_id:
        await vault_setpw_cmd.finish("...这个只能私聊用。")
        return
    content = str(event.message).strip()
    for prefix in ["设置密码", "设密码"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break
    if not content:
        await vault_setpw_cmd.finish("...密码呢。格式：/设置密码 你的密码")
        return
    if len(content) < 4:
        await vault_setpw_cmd.finish("...密码太短了，至少4位。")
        return
    user_id = str(event.user_id)
    vault = _load_vault()
    if user_id not in vault:
        vault[user_id] = {}
    if vault[user_id].get("_password_hash"):
        await vault_setpw_cmd.finish("你已经设置过密码了。如需修改请先 /修改密码")
        return
    vault[user_id]["_password_hash"] = _hash_password(content)
    _save_vault(vault)
    await vault_setpw_cmd.finish("[OK] 保险箱密码设置成功。\n现在可以用 /存 /取 /删密 了。\n格式：/存 密码名|密码 内容")


async def _cmd_vault_changepw(event: MessageEvent):
    """修改保险箱密码：/修改密码 旧密码 新密码"""
    if hasattr(event, 'group_id') and event.group_id:
        await vault_changepw_cmd.finish("...这个只能私聊用。")
        return
    content = str(event.message).strip()
    for prefix in ["修改密码", "改密码"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break
    if not content:
        await vault_changepw_cmd.finish("...格式：/修改密码 旧密码 新密码")
        return
    parts = content.split(None, 1)
    if len(parts) < 2:
        await vault_changepw_cmd.finish("...格式：/修改密码 旧密码 新密码")
        return
    old_pw, new_pw = parts[0], parts[1]
    if len(new_pw) < 4:
        await vault_changepw_cmd.finish("...新密码太短了，至少4位。")
        return
    user_id = str(event.user_id)
    ok, err = _require_password(user_id, old_pw)
    if not ok:
        await vault_changepw_cmd.finish(err)
        return
    # 用新密码重新加密所有条目
    vault = _load_vault()
    user_data = vault.get(user_id, {})
    for key_name in list(user_data.keys()):
        if key_name.startswith("_"):
            continue
        old_encrypted = user_data[key_name]
        decrypted = _decrypt(old_encrypted, old_pw)
        if decrypted is not None:
            user_data[key_name] = _encrypt(decrypted, new_pw)
    user_data["_password_hash"] = _hash_password(new_pw)
    vault[user_id] = user_data
    _save_vault(vault)
    await vault_changepw_cmd.finish("[OK] 密码修改成功，所有数据已重新加密。")


async def _cmd_vault_save(event: MessageEvent):
    """存密码：/存 密码名|密码 内容"""
    if hasattr(event, 'group_id') and event.group_id:
        await vault_save_cmd.finish("...这个只能私聊用。")
        return
    content = str(event.message).strip()
    for prefix in ["存密码", "存密"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break
    if content.startswith("存"):
        content = content[1:].strip()
    if not content:
        await vault_save_cmd.finish("...格式：/存 密码名|密码 内容")
        return
    # 解析 密码名|密码
    pipe_idx = content.find("|")
    if pipe_idx == -1:
        await vault_save_cmd.finish("...格式不对。用 | 分隔名称和密码：\n/存 邮箱|mypassword abc@qq.com")
        return
    name = content[:pipe_idx].strip()
    pw = content[pipe_idx+1:].strip()
    value_part = content[pipe_idx+1+len(pw):].strip()
    if not name or not pw or not value_part:
        await vault_save_cmd.finish("...格式不对。/存 密码名|密码 内容")
        return
    user_id = str(event.user_id)
    ok, err = _require_password(user_id, pw)
    if not ok:
        await vault_save_cmd.finish(err)
        return
    vault = _load_vault()
    if user_id not in vault:
        vault[user_id] = {}
    vault[user_id][name] = _encrypt(value_part, pw)
    _save_vault(vault)
    await vault_save_cmd.finish(f"已保存「{name}」。")


async def _cmd_vault_get(event: MessageEvent):
    """取密码：/取 密码名|密码"""
    if hasattr(event, 'group_id') and event.group_id:
        await vault_get_cmd.finish("...这个只能私聊用。")
        return
    content = str(event.message).strip()
    for prefix in ["取密码", "取密"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break
    if content.startswith("取"):
        content = content[1:].strip()
    if not content:
        await vault_get_cmd.finish("...格式：/取 密码名|密码")
        return
    pipe_idx = content.find("|")
    if pipe_idx == -1:
        await vault_get_cmd.finish("...格式不对。/取 密码名|密码")
        return
    name = content[:pipe_idx].strip()
    pw = content[pipe_idx+1:].strip()
    if not name or not pw:
        await vault_get_cmd.finish("...格式不对。/取 密码名|密码")
        return
    user_id = str(event.user_id)
    ok, err = _require_password(user_id, pw)
    if not ok:
        await vault_get_cmd.finish(err)
        return
    vault = _load_vault()
    user_data = vault.get(user_id, {})
    encrypted = user_data.get(name)
    if not encrypted:
        await vault_get_cmd.finish(f"没有叫「{name}」的记录。")
        return
    value = _decrypt(encrypted, pw)
    if value is None:
        await vault_get_cmd.finish("解密失败，可能是密码不对或数据损坏。")
        return
    await vault_get_cmd.finish(f"【{name}】\n{value}")


async def _cmd_vault_delete(event: MessageEvent):
    """删密码：/删密 密码名|密码"""
    if hasattr(event, 'group_id') and event.group_id:
        await vault_del_cmd.finish("...这个只能私聊用。")
        return
    content = str(event.message).strip()
    for prefix in ["删密码", "删除密码"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break
    if content.startswith("删密"):
        content = content[3:].strip()
    if not content:
        await vault_del_cmd.finish("...格式：/删密 密码名|密码")
        return
    pipe_idx = content.find("|")
    if pipe_idx == -1:
        await vault_del_cmd.finish("...格式不对。/删密 密码名|密码")
        return
    name = content[:pipe_idx].strip()
    pw = content[pipe_idx+1:].strip()
    if not name or not pw:
        await vault_del_cmd.finish("...格式不对。/删密 密码名|密码")
        return
    user_id = str(event.user_id)
    ok, err = _require_password(user_id, pw)
    if not ok:
        await vault_del_cmd.finish(err)
        return
    vault = _load_vault()
    user_data = vault.get(user_id, {})
    if name not in user_data:
        await vault_del_cmd.finish(f"没有叫「{name}」的记录。")
        return
    del vault[user_id][name]
    if not vault[user_id]:
        del vault[user_id]
    _save_vault(vault)
    await vault_del_cmd.finish(f"已删除「{name}」。")


async def _cmd_vault_list(event: MessageEvent):
    """密码列表：/密码列表 密码"""
    if hasattr(event, 'group_id') and event.group_id:
        await vault_list_cmd.finish("...这个只能私聊用。")
        return
    content = str(event.message).strip()
    for prefix in ["密码列表"]:
        if content.startswith(prefix):
            content = content[len(prefix):].strip()
            break
    if not content:
        await vault_list_cmd.finish("...格式：/密码列表 你的密码")
        return
    pw = content.strip()
    user_id = str(event.user_id)
    ok, err = _require_password(user_id, pw)
    if not ok:
        await vault_list_cmd.finish(err)
        return
    vault = _load_vault()
    user_data = vault.get(user_id, {})
    items = {k: v for k, v in user_data.items() if not k.startswith("_")}
    if not items:
        await vault_list_cmd.finish("你还没有存过任何密码。")
        return
    msg = "你的密码列表：\n"
    for i, name in enumerate(items.keys(), 1):
        msg += f"{i}. {name}\n"
    await vault_list_cmd.finish(msg.strip())


vault_setpw_cmd = _register("设置密码", _cmd_vault_setpw, priority=1)
vault_changepw_cmd = _register("修改密码", _cmd_vault_changepw, priority=1)
vault_save_cmd = _register("存", _cmd_vault_save, priority=1)
vault_get_cmd = _register("取", _cmd_vault_get, priority=1)
vault_del_cmd = _register("删密", _cmd_vault_delete, priority=1)
vault_list_cmd = _register("密码列表", _cmd_vault_list, priority=1)
