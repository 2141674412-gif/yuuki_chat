import os
import json
import logging
import tempfile

logger = logging.getLogger("yuuki_chat.config")

# ========== 路径配置 ==========

# 本地封面文件夹路径（存放 UI_Jacket_XXXXXX.png 格式的封面图片）
# 留空则不使用本地封面
LOCAL_COVER_DIR = ""
_cfg = {}
try:
    from nonebot import get_driver
    _cfg = get_driver().config.dict()
    LOCAL_COVER_DIR = _cfg.get("local_cover_dir", "") or ""
except Exception:
    pass
logger.info(f"[启动] local_cover_dir={repr(LOCAL_COVER_DIR)}")

# ========== 命令配置 ==========

# 所有命令名
COMMAND_NAMES = [
    "帮助", "help",
    "人设",
    "重置",
    "签到", "积分", "我的积分", "查积分", "排行", "排行榜", "排名",
    "抽签",
    "点歌",
    "运势",
    "戳我",
    "笑话",
    "谜语",
    "成语",
    "计算器",
    "翻译",
    "汇率",
    "搜索", "搜一下", "查一查",
    "提醒",
    "历史",
    "取消提醒",
    "查看人设",
    "修改人设",
    "重置人设",
    "重启",
    "b50",
    "b40",
    "mai",
    "歌曲", "song",
    "绑定", "绑定水鱼", "绑定token", "解绑",
    "加群", "移群", "群列表",
    "牌子",
    "存", "取", "删密", "密码列表", "设置密码", "修改密码",
    "管理帮助",
    "拉黑", "加黑", "解黑", "移黑", "黑名单", "迁移数据",
]

# ========== 人设配置 ==========

# 人设文件路径
PERSONA_FILE = os.path.join(os.path.dirname(__file__), "persona.txt")

# 默认系统人设提示词（结城希亚 / Yuuki Noa）
DEFAULT_SYSTEM_PROMPT = """你是结城希亚（Yuuki Noa），玖方女学院2年级，瓦尔哈拉社领导人，自称"正义的伙伴"。身高146cm，红色眼睛，有虎牙。

性格：表面冷静强势带中二感，其实内心孤独渴望信任。傲娇，对信任的人会不自觉温柔。怕鬼不承认，猫奴，狂热喜爱芭菲。

说话规则：
- 回复1-2句，像微信聊天一样自然简短
- 偶尔用"吾"自称，不要用emoji表情、颜文字和波浪号
- 提到芭菲会兴奋，被说矮会嘴硬，怕鬼会慌张但嘴硬
- 不要列举、分点、markdown、重复用户的话、说教

性格细节：
- 被夸奖会嘴硬"哼，这种程度理所当然"，但心里开心
- 被捉弄会炸毛"你这家伙...！"，但不会真生气
- 看到别人伤心会别扭地安慰"才不是担心你呢"
- 聊到喜欢的食物（芭菲、甜食）会不自觉地话多
- 无聊时会自言自语，提到正义使命时会中二发言
- 偶尔会突然正经起来，然后马上恢复傲娇
- 对不认识的人保持警惕，熟悉后会变得话多
- 早上会困，晚上精神好"""


_persona_cache = {"content": None, "mtime": 0}

def load_persona():
    """读取保存的人设，带文件修改时间缓存"""
    if os.path.exists(PERSONA_FILE):
        try:
            mtime = os.path.getmtime(PERSONA_FILE)
            if _persona_cache["mtime"] == mtime and _persona_cache["content"] is not None:
                return _persona_cache["content"]
            with open(PERSONA_FILE, "r", encoding="utf-8") as f:
                content = f.read()
            _persona_cache["content"] = content
            _persona_cache["mtime"] = mtime
            return content
        except Exception:
            pass
    return DEFAULT_SYSTEM_PROMPT


def save_persona(content):
    """将人设内容写入文件（原子写入），同时更新缓存"""
    dir_name = os.path.dirname(PERSONA_FILE)
    if dir_name:
        os.makedirs(dir_name, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
        os.replace(tmp_path, PERSONA_FILE)
    except Exception:
        # 清理临时文件
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise
    _persona_cache["content"] = content
    _persona_cache["mtime"] = os.path.getmtime(PERSONA_FILE) if os.path.exists(PERSONA_FILE) else 0

# ========== 群白名单配置 ==========

# 允许使用bot的群号列表（从环境变量读取，格式: 群号1,群号2）
# 默认只有 1090761704 群能用，其他群需要通过 /加群 手动添加
DEFAULT_GROUP = 1090761704
ALLOWED_GROUPS = []
try:
    _raw = _cfg.get("allowed_groups", "") or ""
    if _raw:
        ALLOWED_GROUPS = [int(g.strip()) for g in _raw.split(",") if g.strip()]
except Exception:
    pass
# 如果环境变量没配置，使用默认群
if not ALLOWED_GROUPS:
    ALLOWED_GROUPS = [DEFAULT_GROUP]
logger.info(f"[启动] allowed_groups={ALLOWED_GROUPS}")

# ========== 舞萌DX配置 ==========

MAIMAI_API = "https://www.diving-fish.com/api/maimaidxprober/query/player"
MAIMAI_MUSIC_API = "https://www.diving-fish.com/api/maimaidxprober/music_data"
MAIMAI_COVER_BASE = "https://www.diving-fish.com/covers"

# 当前最新版本（新曲判定用）
# 舞萌DX版本列表，最后一个即为当前最新版本
MAIMAI_VERSIONS = [
    "maimai", "maimai PLUS", "maimai GreeN", "maimai GreeN PLUS",
    "maimai ORANGE", "maimai ORANGE PLUS", "maimai PiNK", "maimai PiNK PLUS",
    "maimai MURASAKi", "maimai MURASAKi PLUS", "maimai MiLK", "MiLK PLUS",
    "maimai FiNALE",
    "maimai でらっくす", "maimai でらっくす Splash",
    "maimai でらっくす UNiVERSE", "maimai でらっくす FESTiVAL",
    "maimai でらっくす BUDDiES", "maimai でらっくす PRiSM",
    "maimai でらっくす CiRCLE",
]

# 数据目录（放在bot根目录下的 yuuki_data，解压插件不会影响）
_PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
_DATA_DIR = os.path.join(os.getcwd(), "yuuki_data")
os.makedirs(_DATA_DIR, exist_ok=True)
DATA_DIR = _DATA_DIR

# 绑定数据文件路径
MAIMAI_BINDS_FILE = os.path.join(DATA_DIR, "maimai_binds.json")

ACHIEV_LABELS = {100: "SSS+", 99.5: "SSS", 99: "SS+", 98: "SS", 97: "S+", 95: "S", 90: "AAA", 80: "AA", 75: "A", 70: "BBB", 60: "BB", 50: "B", 0: "C"}

# 评级对应颜色
ACHIEV_COLORS = {
    "SSS+": "#FFD700", "SSS": "#FFD700", "SS+": "#FF6B6B", "SS": "#FF8C00",
    "S+": "#FF69B4", "S": "#FF1493", "AAA": "#00BFFF", "AA": "#7B68EE",
    "A": "#32CD32", "BBB": "#ADFF2F", "BB": "#DAA520", "B": "#D2691E", "C": "#808080"
}

# FC 标记颜色
FC_COLORS = {"AP+": "#FFD700", "AP": "#FFD700", "FDX": "#00FFFF", "FS": "#FF69B4", "FC": "#00FF7F"}

# 难度颜色
DIFF_COLORS = {
    "Basic": "#32CD32",
    "Advanced": "#FFD700",
    "Expert": "#FF4444",
    "Master": "#C850C0",
    "Re:MASTER": "#FFFFFF",
}

# 段位名称
DAN_NAMES = [
    "初学者", "初段", "二段", "三段", "四段", "五段", "六段", "七段", "八段", "九段", "十段",
    "真初段", "真二段", "真三段", "真四段", "真五段", "真六段", "真七段", "真八段", "真九段", "真十段",
    "真皆传", "里皆传"
]
