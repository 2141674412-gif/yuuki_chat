# 标准库
import asyncio
import base64
import os
import random
import re
import threading
import time
from io import BytesIO

# 第三方库
import httpx
import numpy as np
from nonebot import get_bot, logger, on_message
from nonebot.adapters.onebot.v11 import Bot, GroupMessageEvent, MessageEvent, MessageSegment
from nonebot.exception import FinishedException
from openai import APIError, APITimeoutError, OpenAI
from PIL import Image
from qreader import QReader

# 本地模块
from .config import ALLOWED_GROUPS, COMMAND_NAMES, load_persona

# ========== 配置读取（兼容 .env 大写和 section 两种格式） ==========

# 配置缓存（NoneBot 配置启动后不变，缓存 dict 避免重复创建）
_config_dict = None
try:
    from nonebot import get_driver
    _config_dict = get_driver().config.dict()
except Exception:
    pass

def _cfg(key: str, default: str = "") -> str:
    """读取配置，依次尝试：os.getenv(大写) → driver.config → os.getenv(小写) → 默认值"""
    def _clean(v: str) -> str:
        return v.strip().strip("`").strip("'").strip('"')
    # 1. 环境变量（大写）
    val = os.getenv(key.upper(), "")
    if val:
        return _clean(val)
    # 2. NoneBot driver.config（使用缓存的 dict）
    if _config_dict is not None:
        val = _config_dict.get(key, "") or _config_dict.get(key.upper(), "")
        if val:
            return _clean(str(val))
    # 3. 环境变量（小写）
    val = os.getenv(key, "")
    if val:
        return _clean(val)
    return default

# 初始化 OpenAI 客户端（单例模式，支持断线重连）
_client = None
_client_lock = threading.Lock()

# ---- 全局 HTTP 客户端（连接池复用） ----
from .utils import get_shared_http_client as _get_http_client


def _get_client() -> OpenAI:
    """获取 OpenAI 客户端单例，如果连接失败则重新创建。"""
    global _client
    if _client is None:
        with _client_lock:
            if _client is None:
                _client = OpenAI(
                    api_key=_cfg("api_key", "ollama"),
                    base_url=_cfg("api_base", "http://127.0.0.1:11434/v1")
                )
    return _client


def _reconnect_client():
    """重建 OpenAI 客户端以恢复连接。"""
    global _client
    with _client_lock:
        _client = OpenAI(
            api_key=_cfg("api_key", "ollama"),
            base_url=_cfg("api_base", "http://127.0.0.1:11434/v1")
        )


# 对话历史存储
chat_history = {}

# 对话历史时间戳，用于定期清理
_history_timestamps = {}
_HISTORY_TTL = 3600  # 1 小时过期时间（秒）


def _cleanup_old_histories():
    """清理超过 TTL 的旧对话历史，防止内存泄漏。"""
    now = time.time()
    expired_users = [
        uid for uid, ts in _history_timestamps.items()
        if now - ts > _HISTORY_TTL
    ]
    for uid in expired_users:
        chat_history.pop(uid, None)
        _history_timestamps.pop(uid, None)


# 将命令列表转为集合，加速查找
COMMAND_SET = set(COMMAND_NAMES)

# ========== 艾特检测（睡觉模式） ==========

# 将命令列表转为集合，加速查找主人QQ号
_OWNER_QQ = "2141674412"

# 睡觉回复池
_SLEEP_REPLIES = [
    "...zzz",
    "...别吵，在睡觉。",
    "...zzZ...什么事。",
    "...呼...谁啊。",
    "...再吵把你扔出去。",
    "...困死了，明天再说。",
    "...嗯...zzz...",
    "...五分钟...再睡五分钟...",
    "...别艾特了，在睡觉呢。",
]

_sleep_cmd = on_message(priority=0, block=False)

@_sleep_cmd.handle()
async def handle_sleep_at(event: GroupMessageEvent):
    """群里有人@bot时，如果不是主人@的，回复在睡觉"""
    if not hasattr(event, 'group_id') or not event.group_id:
        return

    # 群白名单检查
    if event.group_id not in ALLOWED_GROUPS:
        return

    # 黑名单检查
    try:
        from .commands import user_blacklist, superusers
        uid = str(event.user_id)
        if uid not in superusers and uid in user_blacklist:
            return
    except Exception:
        pass

    # 检查是否@了bot
    if not getattr(event, 'to_me', False):
        return

    user_id = str(event.user_id)

    # 主人@bot或@希亚，不触发睡觉模式（交给handle_chat处理）
    if user_id == _OWNER_QQ:
        return

    # 检查消息里是否有"希亚"（主人提到希亚不算）
    message = str(event.message)
    # 去掉@标记后检查纯文本
    plain = re.sub(r'\[at:qq=\d+\]', '', message).strip()
    if "希亚" in plain or "Noa" in plain.lower():
        return

    # 随机回复
    reply = random.choice(_SLEEP_REPLIES)
    await _sleep_cmd.finish(reply)


# 消息处理（优先级 1，block=False 让命令能继续传递）
chat = on_message(priority=1, block=False)

@chat.handle()
async def handle_chat(event: MessageEvent):
    user_id = str(event.user_id)
    message = str(event.message)

    # 提取纯文本（去掉 @ 标记和开头的 /）
    plain_text = re.sub(r'\[at:qq=\d+\]', '', message).strip()
    if plain_text.startswith("/"):
        plain_text = plain_text[1:].strip()

    # 如果是命令消息，不处理（使用集合加速查找）
    if plain_text in COMMAND_SET or any(plain_text.startswith(cmd + " ") for cmd in COMMAND_SET):
        return

    # 如果消息包含图片，跳过（交给识图handler处理）
    if any(seg.type == "image" for seg in event.message):
        return

    # 如果消息包含合并转发，跳过（交给合并转发handler处理）
    if any(seg.type == "forward" for seg in event.message):
        return

    # 如果@bot且包含回复消息，跳过（可能是回复合并转发，交给合并转发handler处理）
    is_at_me_check = getattr(event, 'to_me', False)
    if is_at_me_check and any(seg.type == "reply" for seg in event.message):
        return

    # 如果是群聊，需要@bot或提到希亚才回复
    is_at_me = getattr(event, 'to_me', False) or "希亚" in message or "Noa" in message or "noa" in message
    if hasattr(event, 'group_id') and event.group_id:
        if not is_at_me:
            return
        # 群白名单检查
        if event.group_id not in ALLOWED_GROUPS:
            return

    # 被@但没有文字内容时，给一个默认提示
    if not plain_text:
        plain_text = "你在叫我吗？"

    message = plain_text

    # 加载当前人设
    system_prompt = load_persona()

    # 初始化对话历史
    if user_id not in chat_history:
        chat_history[user_id] = [
            {"role": "system", "content": system_prompt}
        ]

    # 添加用户消息
    chat_history[user_id].append({"role": "user", "content": message})

    try:
        # 定期清理过期历史
        _cleanup_old_histories()

        client = _get_client()

        # 流式请求（在线程中执行，避免阻塞事件循环）
        loop = asyncio.get_running_loop()

        def _collect_stream():
            stream = client.chat.completions.create(
                model=_cfg("model_name", "qwen2.5:7b-instruct"),
                messages=chat_history[user_id],
                max_tokens=int(_cfg("max_tokens", "128")),
                temperature=float(_cfg("temperature", "0.7")),
                timeout=20.0,
                stream=True,
            )
            ai_response = ""
            for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    ai_response += chunk.choices[0].delta.content
            return ai_response

        ai_response = await loop.run_in_executor(None, _collect_stream)

        ai_response = ai_response.strip()

        if not ai_response:
            ai_response = "...嗯？"

        chat_history[user_id].append({"role": "assistant", "content": ai_response})
        _history_timestamps[user_id] = time.time()

        # 限制历史记录长度（只保留最近5轮对话）
        if len(chat_history[user_id]) > 11:  # system + 5轮(user+assistant) = 11条
            chat_history[user_id] = [chat_history[user_id][0]] + chat_history[user_id][-10:]

        await chat.finish(ai_response)

    except FinishedException:
        raise
    except APITimeoutError:
        # API 超时，尝试重建客户端连接
        _reconnect_client()
        fallback = "嗯...正义的伙伴好像走神了，再说一次？"
        chat_history[user_id].append({"role": "assistant", "content": fallback})
        _history_timestamps[user_id] = time.time()
        await chat.finish(fallback)
    except APIError as e:
        # API 错误（如服务不可用、速率限制等）
        fallback = "唔...脑袋好像有点转不过来，等一下再来吧。"
        chat_history[user_id].append({"role": "assistant", "content": fallback})
        _history_timestamps[user_id] = time.time()
        await chat.finish(fallback)
    except Exception as e:
        # 其他未预期的错误
        fallback = [
            "嗯？怎么了。",
            "...有事就说。",
            "哼。",
            "正义的伙伴现在有点忙。",
            "...你继续说。",
            "怎么了，有什么事吗。",
        ]

        ai_response = random.choice(fallback)
        chat_history[user_id].append({"role": "assistant", "content": ai_response})
        _history_timestamps[user_id] = time.time()
        await chat.finish(ai_response)


# ========== AI 生成回复 ==========

# 插话用的正经话题（AI失败时的兜底）
_FALLBACK_TOPICS = [
    "今天天气不错呢。",
    "正义的伙伴也是需要休息的。",
    "...有点无聊。",
    "最近有什么新歌吗。",
    "该去巡逻了...啊不，散步。",
    "嗯...在想事情。",
    "有人在吗。",
    "...安静得有点不习惯。",
    "今天也要加油。",
    "肚子饿了...想吃芭菲。",
    "最近好像没什么特别的事。",
    "嗯？什么声音。",
    "...算了，没什么。",
    "这个时间点还挺闲的。",
    "有没有什么有趣的事。",
]

# 生成插话的 prompt（让AI像正常聊天一样回应群消息）
_CHATTER_SYSTEM_PROMPT = """你是结城希亚，正在群聊中。群里有人发了一条消息，你要像正常聊天一样回应他。
要求：
- 回复要简短自然，1-2句话
- 要针对对方说的内容做出有意义的回应
- 保持希亚的性格：冷静、偶尔中二、傲娇、喜欢芭菲
- 不要用markdown、不要分点、不要列举
- 像微信聊天一样自然，不要刻意"""

_PROACTIVE_SYSTEM_PROMPT = """你是结城希亚，现在群里很安静，你想主动说一句话活跃气氛。
要求：
- 只说一句话，不超过15个字
- 要像真人在群里随口说的，自然随意
- 可以是日常感叹、自言自语、或者随便聊点什么
- 保持希亚的性格：冷静、偶尔中二、傲娇、喜欢芭菲
- 不要用markdown、不要分点、不要列举
- 不要说"大家好"这种太正式的话"""


async def _ai_generate_reply(context: str, system_prompt: str) -> str:
    """调用AI生成一条回复"""
    try:
        client = _get_client()
        loop = asyncio.get_running_loop()

        def _do_api():
            return client.chat.completions.create(
                model=_cfg("model_name", "qwen2.5:7b-instruct"),
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": context},
                ],
                max_tokens=128,
                temperature=0.8,
                timeout=15.0
            )

        response = await loop.run_in_executor(None, _do_api)
        if not response.choices or not response.choices[0].message.content:
            return None
        reply = response.choices[0].message.content.strip()
        # 截断过长的回复
        if len(reply) > 60:
            reply = reply[:58] + "..."
        return reply
    except Exception as e:
        logger.warning(f"[AI生成失败] {e}")
        return None


# ========== 随机插话 ==========

# 插话概率（基础概率，话题匹配时会提高）
CHATTER_BASE_PROBABILITY = 0.01  # 1% 基础概率

# 话题关键词及对应插话概率（匹配到这些词时提高插话概率）
_TOPIC_KEYWORDS = {
    # 希亚相关
    "希亚": 0.6, "noa": 0.6, "正义": 0.3, "瓦尔哈拉": 0.5, "玖方": 0.4,
    # 芭菲/甜食
    "芭菲": 0.7, "甜点": 0.3, "蛋糕": 0.3, "冰淇淋": 0.3, "布丁": 0.2, "甜品": 0.3,
    # 猫
    "猫": 0.4, "猫咪": 0.4, "喵": 0.3, "猫猫": 0.4, "撸猫": 0.3,
    # 舞萌
    "舞萌": 0.3, "maimai": 0.3, "mai": 0.2, "推分": 0.2, "牌子": 0.2, "dx": 0.2,
    # 恐怖/鬼
    "鬼": 0.3, "恐怖": 0.3, "吓": 0.2, "灵异": 0.3,
    # 身高相关
    "矮": 0.3, "身高": 0.2, "146": 0.4, "小只": 0.2,
    # 日常
    "无聊": 0.2, "好困": 0.3, "饿了": 0.3, "好吃": 0.2, "游戏": 0.1,
    "动漫": 0.15, "番剧": 0.15, "音乐": 0.1, "歌": 0.1,
}

# 需要跳过的消息关键词（命令、纯图片、CQ码等）
_SKIP_PATTERNS = [r'^\[CQ:', r'^/', r'^\s*$']

chatter = on_message(priority=5, block=False)

@chatter.handle()
async def handle_chatter(event: GroupMessageEvent):
    """群聊智能插话：根据话题关键词判断是否回复"""
    # 只在群聊中生效
    if not hasattr(event, 'group_id') or not event.group_id:
        return

    # 群白名单检查
    if event.group_id not in ALLOWED_GROUPS:
        return

    message = str(event.message)

    # 跳过命令、CQ码、空消息
    for pattern in _SKIP_PATTERNS:
        if re.match(pattern, message):
            return

    # 跳过所有命令（带/或不带/，如"点歌 xxx"也是命令）
    msg_lower = message.lower().lstrip("/")
    if any(msg_lower == cmd or msg_lower.startswith(cmd + " ") for cmd in COMMAND_SET):
        return

    # 跳过已经@希亚的消息（由 handle_chat 处理）
    if "希亚" in message or "Noa" in message or "noa" in message:
        return

    # 计算插话概率：基础概率 + 话题关键词加成
    msg_lower = message.lower()
    max_prob = CHATTER_BASE_PROBABILITY
    for keyword, prob in _TOPIC_KEYWORDS.items():
        if keyword.lower() in msg_lower:
            max_prob = max(max_prob, prob)

    # 概率判断
    if random.random() > max_prob:
        return

    # 用AI生成回复，失败时用预设话题兜底
    reply = await _ai_generate_reply(message, _CHATTER_SYSTEM_PROMPT)
    if not reply:
        reply = random.choice(_FALLBACK_TOPICS)

    await chatter.finish(reply)


# ========== 自动识别二维码 ==========

_qrcode = on_message(priority=5, block=False)

_qr_detector = QReader()

@_qrcode.handle()
async def handle_qrcode(event: MessageEvent):
    """检测图片中的二维码并自动回复内容"""
    # 群白名单检查
    gid = getattr(event, 'group_id', None)
    if gid and gid not in ALLOWED_GROUPS:
        return
    for seg in event.message:
        if seg.type == "image":
            url = seg.data.get("url", "")
            if not url:
                continue
            try:
                logger.debug(f"[二维码] 检测到图片，正在下载: {url[:60]}...")
                try:
                    resp = await _get_http_client().get(url)
                except Exception:
                    continue
                if resp.status_code != 200:
                    logger.debug(f"[二维码] 下载失败: HTTP {resp.status_code}")
                    continue
                img = Image.open(BytesIO(resp.content)).convert("RGB")
                results = _qr_detector.detect_and_decode(np.array(img))
                logger.debug(f"[二维码] 检测结果: {results}")
                if results:
                    text = results[0]
                    if isinstance(text, tuple):
                        text = text[0]
                    if not isinstance(text, str):
                        text = text.data
                    if isinstance(text, bytes):
                        text = text.decode("utf-8", errors="ignore")
                text = text.strip()
                if text:
                    # 如果是SGWCMAID开头的二维码，回复识别结果
                    if text.startswith("SGWCMAID"):
                        logger.debug(f"[二维码] 检测到SGWCMAID: {event.message_id}")
                        await _qrcode.finish(f"识别到机台二维码：\n{text}")
                        return
                    else:
                        await _qrcode.finish(f"识别到二维码：\n{text}")
            except FinishedException:
                raise
            except Exception as e:
                logger.warning(f"[二维码] 识别异常: {e}")


# ========== 合并转发消息查看 ==========

def _has_forward_or_reply_to_forward(event: GroupMessageEvent) -> bool:
    """快速判断消息是否包含 forward 段，或者回复了一条包含 forward 的消息（同步，不调 API）"""
    for seg in event.message:
        if seg.type == "forward":
            return True
    for seg in event.message:
        if seg.type == "reply":
            return True  # 有 reply 段，可能引用了合并转发，交给 handler 异步确认
    return False

_forward_reader = on_message(priority=0, block=False, rule=_has_forward_or_reply_to_forward)

@_forward_reader.handle()
async def handle_forward_msg(bot: Bot, event: GroupMessageEvent):
    """当有人@bot并发送合并转发消息时，读取并展示内容"""
    # 必须在群里且@了bot
    if not hasattr(event, 'group_id') or not event.group_id:
        return
    is_at_me = getattr(event, 'to_me', False)
    if not is_at_me:
        return
    if event.group_id not in ALLOWED_GROUPS:
        return

    # 检查消息中是否包含合并转发消息段
    forward_seg = None
    for seg in event.message:
        if seg.type == "forward":
            forward_seg = seg
            break

    # 如果当前消息没有 forward，检查是否回复了一条合并转发消息
    if not forward_seg:
        for seg in event.message:
            if seg.type == "reply":
                reply_id = seg.data.get("id", "")
                if reply_id:
                    try:
                        replied = await bot.call_api("get_msg", message_id=int(reply_id))
                        replied_msg = replied.get("message", [])
                        logger.info(f"[合并转发] get_msg 返回: type={type(replied_msg).__name__}, len={len(replied_msg) if hasattr(replied_msg, '__len__') else '?'}")
                        # message 可能是 list 或 Message 对象，统一转为 list 遍历
                        for rseg in replied_msg:
                            seg_type = rseg.type if hasattr(rseg, 'type') else rseg.get("type", "")
                            seg_data = rseg.data if hasattr(rseg, 'data') else rseg.get("data", {})
                            logger.info(f"[合并转发] 段: type={seg_type}, data_keys={list(seg_data.keys()) if isinstance(seg_data, dict) else '?'}")
                            if seg_type == "forward":
                                forward_seg = rseg
                                break
                    except Exception as e:
                        logger.warning(f"[合并转发] 获取回复消息失败: {type(e).__name__}: {e}")
                break

    if not forward_seg:
        return

    forward_id = forward_seg.data.get("id", "")
    if not forward_id:
        await _forward_reader.finish("...这个合并消息好像有问题，读不出来。")
        return

    try:
        # 调用 OneBot API 获取合并转发内容
        result = await bot.call_api("get_forward_msg", message_id=forward_id)
        messages = result.get("message", [])
        if not messages:
            await _forward_reader.finish("...这个合并消息是空的。")
            return

        # 提取每条消息的发送者和内容
        lines = []
        for node in messages:
            sender = node.get("sender", {})
            nickname = sender.get("nickname", "未知") or sender.get("card", "未知") or "未知"
            # node 的 content 可能是 message 段列表
            content = node.get("content", [])
            if isinstance(content, str):
                text = content.strip()
            elif isinstance(content, list):
                # 从消息段列表中提取文本
                text_parts = []
                for seg in content:
                    if seg.get("type") == "text":
                        text_parts.append(seg.get("data", {}).get("text", ""))
                    elif seg.get("type") == "image":
                        text_parts.append("[图片]")
                    elif seg.get("type") == "face":
                        text_parts.append("[表情]")
                    elif seg.get("type") == "at":
                        qq = seg.get("data", {}).get("qq", "")
                        text_parts.append(f"[@{qq}]")
                    elif seg.get("type") == "record":
                        text_parts.append("[语音]")
                    elif seg.get("type") == "video":
                        text_parts.append("[视频]")
                text = "".join(text_parts).strip()
            else:
                text = str(content).strip()

            if text:
                # 截断过长的单条消息
                display = text[:500] + "..." if len(text) > 500 else text
                lines.append(f"【{nickname}】{display}")

        if not lines:
            await _forward_reader.finish("...这个合并消息里没有文字内容。")
            return

        # 合并输出，分段发送（QQ 单条消息限制约 4500 字符）
        output = "\n".join(lines)
        max_len = 4000
        if len(output) <= max_len:
            await _forward_reader.finish(output)
        else:
            # 分段发送
            parts = []
            current = ""
            for line in lines:
                if len(current) + len(line) + 1 > max_len:
                    if current:
                        parts.append(current)
                    current = line
                else:
                    current = current + "\n" + line if current else line
            if current:
                parts.append(current)
            for i, part in enumerate(parts):
                if i == len(parts) - 1:
                    await _forward_reader.finish(part)
                else:
                    await _forward_reader.send(part)

    except FinishedException:
        raise
    except Exception as e:
        logger.warning(f"[合并转发] 读取失败: {e}")
        await _forward_reader.finish(f"...读不出来，可能消息过期了或者不支持。({type(e).__name__})")


# ========== 图片理解 ==========

_img_chat = on_message(priority=4, block=False)

_IMG_SYSTEM_PROMPT = """你是结城希亚，有人发了一张图片给你看。请用1-2句话描述你看到了什么，并给出自然的反应。
要求：
- 像日常聊天一样，不要列举
- 保持希亚的性格：傲娇、偶尔中二
- 如果图片是可爱的东西（猫、甜食等），会不自觉开心
- 如果图片很奇怪，会吐槽
- 不要用markdown"""

@_img_chat.handle()
async def handle_image_chat(event: MessageEvent):
    """发图片给bot时，AI理解图片内容并回复（群聊需@，私聊直接发）"""
    # 群白名单检查
    gid = getattr(event, 'group_id', None)
    if gid and gid not in ALLOWED_GROUPS:
        return

    # 群聊需要@bot才触发，私聊直接触发
    if gid:
        is_at_me = getattr(event, 'to_me', False) or "希亚" in str(event.message) or "Noa" in str(event.message)
        if not is_at_me:
            return

    # 检查消息是否包含图片
    has_image = any(seg.type == "image" for seg in event.message)
    if not has_image:
        return

    # 提取纯文本（去掉@标记）
    plain = re.sub(r'\[at:qq=\d+\]', '', str(event.message)).strip()

    # 下载第一张图片
    img_url = ""
    for seg in event.message:
        if seg.type == "image":
            img_url = seg.data.get("url", "")
            break

    if not img_url:
        return

    try:
        # 下载图片
        resp = await _get_http_client().get(img_url)
        if resp.status_code != 200:
            return
        img_data = resp.content

        # 使用视觉模型（默认 glm-4v-flash，可通过 VISION_MODEL 配置）
        vision_model = _cfg("vision_model", "glm-4v-flash")
        client = _get_client()
        # 将图片转为 base64
        img_b64 = base64.b64encode(img_data).decode("utf-8")

        user_content = []
        if plain:
            user_content.append({"type": "text", "text": plain})
        user_content.append({
            "type": "image_url",
            "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"}
        })

        loop = asyncio.get_running_loop()

        def _do_vision():
            return client.chat.completions.create(
                model=vision_model,
                messages=[
                    {"role": "system", "content": _IMG_SYSTEM_PROMPT},
                    {"role": "user", "content": user_content},
                ],
                max_tokens=int(_cfg("max_tokens", "128")),
                temperature=float(_cfg("temperature", "0.7")),
                timeout=15.0
            )

        response = await loop.run_in_executor(None, _do_vision)
        if not response.choices or not response.choices[0].message.content:
            return
        reply = response.choices[0].message.content.strip()
        if reply:
            await _img_chat.finish(reply)
    except Exception as e:
        # 模型不支持视觉或请求失败，静默忽略（让二维码handler或其他处理）
        logger.debug(f"[图片理解] 失败（模型可能不支持视觉）: {type(e).__name__}: {str(e)[:80]}")


# ========== 定时主动发言 ==========

# 发言间隔范围（秒）
AUTO_CHAT_MIN_INTERVAL = 30 * 60   # 30分钟
AUTO_CHAT_MAX_INTERVAL = 60 * 60   # 60分钟

# 需要主动发言的群（从环境变量读取，格式: 群号1,群号2）
_auto_chat_groups = []
_auto_chat_enabled = False
_auto_chat_task = None

def _load_auto_chat_config():
    """从环境变量加载自动发言群列表"""
    global _auto_chat_groups, _auto_chat_enabled
    raw = _cfg("auto_chat_groups", "")
    if raw:
        _auto_chat_groups = [g.strip() for g in raw.split(",") if g.strip()]
        _auto_chat_enabled = len(_auto_chat_groups) > 0


async def _auto_chat_loop():
    """定时主动发言的异步循环"""
    global _auto_chat_task
    await asyncio.sleep(60)  # 启动后等1分钟再开始

    # 主动发言的随机话题（给AI一些灵感）
    proactive_hints = [
        "群里现在很安静",
        "到了下午茶时间了",
        "今天好像没什么事",
        "有点无聊想找人聊天",
        "刚吃完东西",
        "在看窗外的风景",
        "在想接下来做什么",
        "突然想到了什么",
        "该做点什么好呢",
        "天气怎么样呢",
    ]

    while True:
        try:
            # 随机等待 30~60 分钟
            interval = random.randint(AUTO_CHAT_MIN_INTERVAL, AUTO_CHAT_MAX_INTERVAL)
            await asyncio.sleep(interval)

            if not _auto_chat_groups:
                continue

            # 随机选一个群
            group_id = random.choice(_auto_chat_groups)

            # 用AI生成发言
            hint = random.choice(proactive_hints)
            reply = await _ai_generate_reply(hint, _PROACTIVE_SYSTEM_PROMPT)
            if not reply:
                reply = random.choice(_FALLBACK_TOPICS)

            # 发送消息
            try:
                bot = get_bot()
                await bot.call_api(
                    "send_group_msg",
                    group_id=int(group_id),
                    message=reply
                )
                logger.info(f"[自动发言] 群{group_id}: {reply}")
            except Exception as e:
                logger.warning(f"[自动发言失败] 群{group_id}: {e}")

        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.error(f"[自动发言异常] {e}")
            await asyncio.sleep(60)  # 出错后等1分钟再试


def start_auto_chat():
    """启动定时发言任务（在 bot 启动后调用）"""
    global _auto_chat_task
    _load_auto_chat_config()
    if _auto_chat_enabled:
        _auto_chat_task = asyncio.create_task(_auto_chat_loop())
        logger.info(f"[自动发言] 已启动，监控群: {_auto_chat_groups}")


# NoneBot2 驱动器启动钩子
from nonebot import get_driver
driver = get_driver()

@driver.on_startup
async def on_bot_startup():
    """bot 启动后启动自动发言任务"""
    start_auto_chat()
